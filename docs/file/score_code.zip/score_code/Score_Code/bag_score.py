#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standalone ROS bag trajectory tracking scorer.

Expected topics by default:
  /MVD/odom      nav_msgs/Odometry
  /setpoints_cmd quadrotor_msgs/PositionCommand

This tool is deliberately independent from PX4 ULog analysis. It never reads
or references a .ulg file.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import yaml
from scipy.spatial import cKDTree

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


@dataclass
class BagData:
    t: np.ndarray
    pos: np.ndarray
    vel: np.ndarray
    sp_t: np.ndarray
    sp_pos: np.ndarray
    sp_vel: np.ndarray
    start_t: float
    end_t: float
    duration: float
    setpoint_path_length: float


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def ensure_dir(path: str) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def unique_sorted_time(t: np.ndarray, *arrays: np.ndarray):
    t = np.asarray(t, dtype=float)
    order = np.argsort(t)
    t = t[order]
    arrays = [np.asarray(a)[order] for a in arrays]
    t_unique, idx = np.unique(t, return_index=True)
    arrays = [a[idx] for a in arrays]
    return (t_unique, *arrays)


def interp_columns(dst_t: np.ndarray, src_t: np.ndarray, src: np.ndarray) -> np.ndarray:
    dst_t = np.asarray(dst_t, dtype=float)
    src_t = np.asarray(src_t, dtype=float)
    src = np.asarray(src, dtype=float)
    if src.ndim == 1:
        return np.interp(dst_t, src_t, src)
    out = np.empty((len(dst_t), src.shape[1]), dtype=float)
    for j in range(src.shape[1]):
        out[:, j] = np.interp(dst_t, src_t, src[:, j])
    return out


def rms(x: np.ndarray) -> float:
    x = np.asarray(x, dtype=float)
    if x.size == 0:
        return float("nan")
    return float(np.sqrt(np.nanmean(np.square(x))))


def norm_metrics(err_vec: np.ndarray) -> Dict[str, float]:
    e = np.linalg.norm(np.asarray(err_vec, dtype=float), axis=1)
    return {
        "rmse": rms(e),
        "mean": float(np.nanmean(e)),
        "p95": float(np.nanpercentile(e, 95)),
        "max": float(np.nanmax(e)),
    }


def msg_stamp_to_sec(msg, bag_t, use_header_stamp: bool) -> float:
    if use_header_stamp and hasattr(msg, "header") and hasattr(msg.header, "stamp"):
        try:
            s = float(msg.header.stamp.to_sec())
            if s > 0:
                return s
        except Exception:
            pass
    try:
        return float(bag_t.to_sec())
    except Exception:
        return float(bag_t)


def read_rosbag(
    bag_path: str,
    odom_topic: str,
    setpoint_topic: str,
    use_header_stamp: bool,
    cfg: dict,
) -> BagData:
    try:
        import rosbag
    except ImportError as exc:
        raise RuntimeError(
            "Cannot import rosbag. Run in a ROS Noetic shell first:\n"
            "  source /opt/ros/noetic/setup.bash\n"
            "  source <your_ws>/devel/setup.bash"
        ) from exc

    odom_t, odom_pos, odom_vel = [], [], []
    sp_t, sp_pos, sp_vel = [], [], []

    with rosbag.Bag(bag_path, "r") as bag:
        info = bag.get_type_and_topic_info().topics
        if odom_topic not in info:
            raise RuntimeError(f"Missing bag topic: {odom_topic}")
        if setpoint_topic not in info:
            raise RuntimeError(f"Missing bag topic: {setpoint_topic}")

        for topic, msg, bt in bag.read_messages(topics=[odom_topic, setpoint_topic]):
            ts = msg_stamp_to_sec(msg, bt, use_header_stamp)
            if topic == odom_topic:
                try:
                    p = msg.pose.pose.position
                    v = msg.twist.twist.linear
                    odom_t.append(ts)
                    odom_pos.append([p.x, p.y, p.z])
                    odom_vel.append([v.x, v.y, v.z])
                except AttributeError as exc:
                    raise RuntimeError(
                        f"{odom_topic} must be nav_msgs/Odometry-compatible."
                    ) from exc
            else:
                try:
                    p = msg.position
                    v = msg.velocity
                    sp_t.append(ts)
                    sp_pos.append([p.x, p.y, p.z])
                    sp_vel.append([v.x, v.y, v.z])
                except AttributeError as exc:
                    raise RuntimeError(
                        f"{setpoint_topic} must contain .position and .velocity fields."
                    ) from exc

    if len(odom_t) < 10 or len(sp_t) < 10:
        raise RuntimeError(f"Too few messages: odom={len(odom_t)}, setpoint={len(sp_t)}")

    odom_t, odom_pos, odom_vel = unique_sorted_time(
        np.asarray(odom_t), np.asarray(odom_pos), np.asarray(odom_vel)
    )
    sp_t, sp_pos, sp_vel = unique_sorted_time(
        np.asarray(sp_t), np.asarray(sp_pos), np.asarray(sp_vel)
    )

    speed_thr = float(cfg.get("motion_speed_threshold_mps", 0.05))
    padding = float(cfg.get("motion_padding_s", 0.25))
    sp_speed = np.linalg.norm(sp_vel, axis=1)
    moving = np.where(sp_speed > speed_thr)[0]

    if moving.size >= 2:
        start_t = max(float(sp_t[0]), float(sp_t[moving[0]]) - padding)
        end_t = min(float(sp_t[-1]), float(sp_t[moving[-1]]) + padding)
    else:
        start_t = float(sp_t[0])
        end_t = float(sp_t[-1])

    start_t = max(start_t, float(odom_t[0]), float(sp_t[0]))
    end_t = min(end_t, float(odom_t[-1]), float(sp_t[-1]))
    if end_t <= start_t:
        raise RuntimeError("No common time overlap between odom and setpoint.")

    om = (odom_t >= start_t) & (odom_t <= end_t)
    sm = (sp_t >= start_t) & (sp_t <= end_t)
    odom_t2, odom_pos2, odom_vel2 = odom_t[om], odom_pos[om], odom_vel[om]
    sp_t2, sp_pos2, sp_vel2 = sp_t[sm], sp_pos[sm], sp_vel[sm]

    if len(odom_t2) < 10 or len(sp_t2) < 10:
        raise RuntimeError("Too few samples after selecting the trajectory window.")

    path_len = float(np.sum(np.linalg.norm(np.diff(sp_pos2, axis=0), axis=1)))

    return BagData(
        t=odom_t2,
        pos=odom_pos2,
        vel=odom_vel2,
        sp_t=sp_t2,
        sp_pos=sp_pos2,
        sp_vel=sp_vel2,
        start_t=start_t,
        end_t=end_t,
        duration=end_t - start_t,
        setpoint_path_length=path_len,
    )


def estimate_tracking_delay(
    actual_t: np.ndarray,
    actual_pos: np.ndarray,
    sp_t: np.ndarray,
    sp_pos: np.ndarray,
    max_delay_s: float,
    step_s: float,
) -> Tuple[float, float]:
    if step_s <= 0:
        step_s = 0.005
    delays = np.arange(-abs(max_delay_s), abs(max_delay_s) + 0.5 * step_s, step_s)
    best_lag = 0.0
    best_rmse = float("inf")

    for tau in delays:
        # Positive tau means actual response lags the command by tau seconds.
        query_t = actual_t - tau
        valid = (query_t >= sp_t[0]) & (query_t <= sp_t[-1])
        if np.count_nonzero(valid) < 20:
            continue
        desired = interp_columns(query_t[valid], sp_t, sp_pos)
        err = actual_pos[valid] - desired
        value = rms(np.linalg.norm(err, axis=1))
        if value < best_rmse:
            best_rmse = value
            best_lag = float(tau)
    return best_lag, best_rmse


def analyze_bag(data: BagData, cfg: dict) -> Tuple[Dict[str, float], Dict[str, np.ndarray]]:
    sp_pos_i = interp_columns(data.t, data.sp_t, data.sp_pos)
    sp_vel_i = interp_columns(data.t, data.sp_t, data.sp_vel)

    pos_err_vec = data.pos - sp_pos_i
    vel_err_vec = data.vel - sp_vel_i
    pm = norm_metrics(pos_err_vec)
    vm = norm_metrics(vel_err_vec)

    tree = cKDTree(data.sp_pos)
    cross_dist, _ = tree.query(data.pos, k=1)
    cross_rmse = rms(cross_dist)

    delay, delay_rmse = estimate_tracking_delay(
        data.t,
        data.pos,
        data.sp_t,
        data.sp_pos,
        float(cfg.get("delay_search_max_s", 0.5)),
        float(cfg.get("delay_search_step_s", 0.005)),
    )

    metrics = {
        "position.rmse_m": pm["rmse"],
        "position.p95_m": pm["p95"],
        "position.max_m": pm["max"],
        "position.cross_track_rmse_m": cross_rmse,
        "velocity.rmse_mps": vm["rmse"],
        "velocity.delay_abs_s": abs(delay),
        "debug.signed_delay_s": delay,
        "debug.delay_aligned_position_rmse_m": delay_rmse,
        "debug.velocity_p95_mps": vm["p95"],
        "debug.velocity_max_mps": vm["max"],
        "debug.trajectory_duration_s": data.duration,
        "debug.setpoint_path_length_m": data.setpoint_path_length,
    }
    series = {
        "t": data.t - data.start_t,
        "actual_pos": data.pos,
        "desired_pos": sp_pos_i,
        "actual_vel": data.vel,
        "desired_vel": sp_vel_i,
        "position_error_norm": np.linalg.norm(pos_err_vec, axis=1),
        "velocity_error_norm": np.linalg.norm(vel_err_vec, axis=1),
        "cross_track_error": np.asarray(cross_dist),
    }
    return metrics, series


def lower_is_better_score(value: float, excellent: float, fail: float, weight: float) -> float:
    if not np.isfinite(value):
        return float("nan")
    if value <= excellent:
        return weight
    if value >= fail:
        return 0.0
    return weight * (fail - value) / (fail - excellent)


def binary_score(value: float, weight: float) -> float:
    if not np.isfinite(value):
        return float("nan")
    return weight if value >= 0.5 else 0.0


def flatten_scoring_config(scoring: dict):
    rows = []
    for category, items in scoring.items():
        for metric_name, rule in items.items():
            rows.append((f"{category}.{metric_name}", rule))
    return rows


def calculate_scores(metrics: Dict[str, float], cfg: dict):
    rows = []
    total = 0.0
    max_total = 0.0
    categories = {}

    for key, rule in flatten_scoring_config(cfg["scoring"]):
        weight = float(rule["weight"])
        max_total += weight
        value = float(metrics.get(key, float("nan")))
        typ = str(rule.get("type", "lower_is_better"))
        if typ == "lower_is_better":
            score = lower_is_better_score(value, float(rule["excellent"]), float(rule["fail"]), weight)
        elif typ == "binary":
            score = binary_score(value, weight)
        else:
            raise ValueError(f"Unknown scoring type {typ} for {key}")

        missing = not np.isfinite(score)
        effective = 0.0 if missing else float(score)
        total += effective
        category = key.split(".", 1)[0]
        categories.setdefault(category, [0.0, 0.0])
        categories[category][0] += effective
        categories[category][1] += weight
        rows.append({
            "metric": key,
            "value": None if not np.isfinite(value) else value,
            "score": effective,
            "max_score": weight,
            "missing": missing,
            "rule": rule,
        })

    return {
        "total": total,
        "max_total": max_total,
        "rows": rows,
        "categories": {k: {"score": v[0], "max_score": v[1]} for k, v in categories.items()},
    }


def grade_for_score(score_100: float, meta: dict) -> str:
    if score_100 >= float(meta.get("grade_A", 90)):
        return "A"
    if score_100 >= float(meta.get("grade_B", 80)):
        return "B"
    if score_100 >= float(meta.get("grade_C", 70)):
        return "C"
    if score_100 >= float(meta.get("grade_D", 60)):
        return "D"
    return "F"


def save_plot(path: Path):
    plt.tight_layout()
    plt.savefig(path, dpi=160, bbox_inches="tight")
    plt.close()


def make_plots(output: Path, s: dict):
    a = s["actual_pos"]
    d = s["desired_pos"]

    plt.figure(figsize=(7, 6))
    plt.plot(d[:, 0], d[:, 1], label="Desired")
    plt.plot(a[:, 0], a[:, 1], label="Actual")
    plt.xlabel("X [m]")
    plt.ylabel("Y [m]")
    plt.title("8-figure trajectory tracking")
    plt.axis("equal")
    plt.grid(True)
    plt.legend()
    save_plot(output / "trajectory_xy.png")

    plt.figure(figsize=(8, 4.5))
    plt.plot(s["t"], s["position_error_norm"], label="3D position error")
    plt.plot(s["t"], s["cross_track_error"], label="Cross-track error")
    plt.xlabel("Time [s]")
    plt.ylabel("Error [m]")
    plt.title("Position tracking error")
    plt.grid(True)
    plt.legend()
    save_plot(output / "position_error.png")

    plt.figure(figsize=(8, 4.5))
    plt.plot(s["t"], s["velocity_error_norm"], label="3D velocity error")
    plt.xlabel("Time [s]")
    plt.ylabel("Error [m/s]")
    plt.title("Velocity tracking error")
    plt.grid(True)
    plt.legend()
    save_plot(output / "velocity_error.png")

    plt.figure(figsize=(9, 6))
    for j, name in enumerate(["X", "Y", "Z"]):
        plt.plot(s["t"], s["desired_pos"][:, j], "--", label=f"{name} desired")
        plt.plot(s["t"], s["actual_pos"][:, j], label=f"{name} actual")
    plt.xlabel("Time [s]")
    plt.ylabel("Position [m]")
    plt.title("Position setpoint vs odometry")
    plt.grid(True)
    plt.legend(ncol=2)
    save_plot(output / "position_tracking_xyz.png")

    plt.figure(figsize=(9, 6))
    for j, name in enumerate(["X", "Y", "Z"]):
        plt.plot(s["t"], s["desired_vel"][:, j], "--", label=f"{name} desired")
        plt.plot(s["t"], s["actual_vel"][:, j], label=f"{name} actual")
    plt.xlabel("Time [s]")
    plt.ylabel("Velocity [m/s]")
    plt.title("Velocity setpoint vs odometry")
    plt.grid(True)
    plt.legend(ncol=2)
    save_plot(output / "velocity_tracking_xyz.png")


def unit_for_metric(key: str) -> str:
    if key.endswith("_m"):
        return "m"
    if key.endswith("_mps"):
        return "m/s"
    if key.endswith("_s"):
        return "s"
    return ""


def write_csv(output: Path, score_result: dict):
    with open(output / "score_summary.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value", "unit", "score", "max_score", "missing"])
        for r in score_result["rows"]:
            w.writerow([
                r["metric"],
                "" if r["value"] is None else f"{r['value']:.8g}",
                unit_for_metric(r["metric"]),
                f"{r['score']:.3f}",
                f"{r['max_score']:.3f}",
                int(r["missing"]),
            ])


def jsonable(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, dict):
        return {k: jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [jsonable(v) for v in obj]
    return obj


def print_summary(metrics: dict, scores: dict, grade: str, payload: Optional[float]):
    print("=" * 68)
    print(" BAG Trajectory Tracking Evaluation")
    print("=" * 68)
    if payload is not None:
        print(f"Payload record: {payload:.1f} g")

    print("\nCategory scores")
    for category, s in scores["categories"].items():
        print(f"  {category:18s} {s['score']:7.2f} / {s['max_score']:.2f}")

    print("\nKey metrics")
    for k in [
        "position.rmse_m", "position.p95_m", "position.max_m",
        "position.cross_track_rmse_m", "velocity.rmse_mps", "velocity.delay_abs_s",
        "debug.trajectory_duration_s", "debug.setpoint_path_length_m",
    ]:
        if k in metrics and np.isfinite(metrics[k]):
            print(f"  {k:40s} {metrics[k]:.6g} {unit_for_metric(k)}")

    print("\n" + "-" * 68)
    print(f"Bag Score:            {scores['total']:.2f} / {scores['max_total']:.0f}")
    print(f"Bag Grade:            {grade}")
    print("NOTE: This is a standalone BAG score. Do not assume it matches any ULog flight.")
    print("=" * 68)


def main():
    ap = argparse.ArgumentParser(description="Standalone UAV 8-figure trajectory scorer from ROS1 bag")
    ap.add_argument("--bag", required=True, help="ROS1 .bag file")
    ap.add_argument("--config", default="bag_scoring.yaml", help="Bag scoring YAML")
    ap.add_argument("--output", default="bag_score_result", help="Output directory")
    ap.add_argument("--payload", type=float, default=None, help="Payload mass in grams, record only")
    ap.add_argument("--odom-topic", default=None)
    ap.add_argument("--setpoint-topic", default=None)
    ap.add_argument("--no-plots", action="store_true")
    args = ap.parse_args()

    cfg = load_yaml(args.config)
    out = ensure_dir(args.output)
    bag_cfg = cfg.get("bag", {})
    odom_topic = args.odom_topic or bag_cfg.get("odom_topic", "/MVD/odom")
    setpoint_topic = args.setpoint_topic or bag_cfg.get("setpoint_topic", "/setpoints_cmd")

    data = read_rosbag(
        args.bag,
        odom_topic,
        setpoint_topic,
        bool(bag_cfg.get("use_header_stamp", True)),
        bag_cfg,
    )
    metrics, series = analyze_bag(data, bag_cfg)
    metrics["task.data_complete"] = 1.0
    traj_ok = (
        data.duration >= float(bag_cfg.get("min_trajectory_duration_s", 18.0))
        and data.setpoint_path_length >= float(bag_cfg.get("min_setpoint_path_length_m", 5.0))
    )
    metrics["task.trajectory_complete"] = 1.0 if traj_ok else 0.0

    scores = calculate_scores(metrics, cfg)
    expected_max = float(cfg.get("meta", {}).get("max_score", 100.0))
    if abs(scores["max_total"] - expected_max) > 1e-6:
        raise ValueError(f"Scoring weights sum to {scores['max_total']:.6g}, expected {expected_max:.6g}")
    grade = grade_for_score(scores["total"], cfg.get("meta", {}))

    if not args.no_plots:
        make_plots(out, series)
    write_csv(out, scores)

    result = {
        "analysis_type": "bag_trajectory",
        "input": {
            "bag": os.path.abspath(args.bag),
            "config": os.path.abspath(args.config),
            "odom_topic": odom_topic,
            "setpoint_topic": setpoint_topic,
            "payload_g": args.payload,
        },
        "metrics": metrics,
        "score": {
            "total": scores["total"],
            "max_score": scores["max_total"],
            "grade": grade,
            "categories": scores["categories"],
            "rows": scores["rows"],
        },
    }
    with open(out / "score_summary.json", "w", encoding="utf-8") as f:
        json.dump(jsonable(result), f, ensure_ascii=False, indent=2)

    print_summary(metrics, scores, grade, args.payload)
    print(f"Results written to: {out.resolve()}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        eprint("ERROR:", exc)
        if os.environ.get("UAV_SCORE_DEBUG", "0") == "1":
            traceback.print_exc()
        sys.exit(2)
