# UAV course scoring tools

Bag and PX4 ULog are analyzed independently. They do **not** need to come from the same flight.

## 1. ROS Bag trajectory score

The Bag tool uses:

- `/MVD/odom`: actual position and velocity
- `/setpoints_cmd`: desired position and velocity

Run:

```bash
source /opt/ros/noetic/setup.bash
python3 bag_score.py \
  --bag flight.bag \
  --config bag_scoring.yaml \
  --payload 200 \
  --output bag_result
```

Bag score is independently out of 100.

## 2. PX4 ULog delay + vibration score

The ULog tool is intentionally simplified. It does **not** analyze or score:

- failsafe
- attitude tracking RMSE/P95
- angular-rate tracking RMSE/P95
- position/velocity error
- motor saturation
- gyro clipping

It only scores:

1. **Attitude response delay + angular-rate response delay — 40 points**
   - `vehicle_rates_setpoint` is treated as the input/setpoint.
   - `vehicle_angular_velocity` is treated as the actual response.
   - The program searches for the time shift that gives the highest normalized correlation.
   - Positive delay means the actual angular-rate response lags the setpoint.

2. **Gyro high-frequency vibration — 40 points**
   - Preferred source: `sensor_gyro_fifo`.
   - Default frequency band: 80–900 Hz.
   - Welch PSD is integrated over the configured band and converted to an RMS vibration value.

3. **Actuator high-frequency vibration — 20 points**
   - Source: `actuator_motors.control[]`.
   - Default frequency band: 20–150 Hz.
   - Welch PSD is integrated over the configured band.

Total ULog score is directly **100 points**.

Run:

```bash
python3 ulog_score.py \
  --ulg flight.ulg \
  --config ulog_scoring.yaml \
  --payload 200 \
  --output ulog_result
```

Install dependencies if needed:

```bash
pip3 install pyulog numpy scipy matplotlib pyyaml
```

Typical ULog outputs:

```text
ulog_result/
├── score_summary.json
├── score_summary.csv
├── rate_response_delay.png
├── delay_correlation.png
├── gyro_psd.png
├── actuator_output.png
└── actuator_psd.png
```

### ULog scoring thresholds

Default delay score:

- absolute delay ≤ 0.03 s: full 40 points
- absolute delay ≥ 0.20 s: 0 points
- linearly interpolated in between

Default gyro vibration score:

- high-frequency RMS ≤ 0.08 rad/s: full 40 points
- high-frequency RMS ≥ 0.50 rad/s: 0 points
- linearly interpolated in between

Default actuator vibration score:

- high-frequency RMS ≤ 0.015: full 20 points
- high-frequency RMS ≥ 0.10: 0 points
- linearly interpolated in between

All thresholds and frequency bands can be changed in `ulog_scoring.yaml` without editing Python code.
