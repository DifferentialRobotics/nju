#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Standalone PX4 ULog response-delay and vibration scorer.

Analyzes attitude response delay, angular-rate response delay, and
gyro/actuator high-frequency vibration. It intentionally does NOT score
attitude/rate tracking error magnitude, P95 error, failsafe state, motor
saturation, or gyro clipping. This tool is independent from ROS bag
trajectory analysis.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import re
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import yaml
from scipy import signal

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

EPS = 1e-12


@dataclass
class ULogResult:
    metrics: Dict[str, float]
    series: Dict[str, np.ndarray]
    warnings: List[str]
    flight_window: Optional[Tuple[float, float]]


def eprint(*args, **kwargs):
    print(*args, file=sys.stderr, **kwargs)


def load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def ensure_dir(path: str) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def finite_rows(*arrays: np.ndarray) -> np.ndarray:
    mask = None
    for a in arrays:
        a = np.asarray(a)
        m = np.isfinite(a)
        if a.ndim > 1:
            m = np.all(m, axis=1)
        mask = m if mask is None else (mask & m)
    return mask


def interp_columns(dst_t: np.ndarray, src_t: np.ndarray, src: np.ndarray) -> np.ndarray:
    dst_t = np.asarray(dst_t, dtype=float)
    src_t = np.asarray(src_t, dtype=float)
    src = np.asarray(src, dtype=float)
    if src.ndim == 1:
        return np.interp(dst_t, src_t, src)
    out = np.empty((len(dst_t), src.shape[1]), dtype=float)
    for j in range(src.shape[1]):
        out[:, j] = np.interp(dst_t, src_t, src[:, j])
    return out


def get_dataset(ulog, name: str, multi_id: int = 0):
    for ds in ulog.data_list:
        if ds.name == name and int(getattr(ds, "multi_id", 0)) == int(multi_id):
            return ds
    for ds in ulog.data_list:
        if ds.name == name:
            return ds
    return None


def dataset_time(ds) -> np.ndarray:
    d = ds.data
    if "timestamp_sample" in d:
        return np.asarray(d["timestamp_sample"], dtype=float) * 1e-6
    if "timestamp" in d:
        return np.asarray(d["timestamp"], dtype=float) * 1e-6
    raise KeyError(f"Dataset {ds.name} has no timestamp field")


def ulog_vector(ds, prefixes: Sequence[str]) -> Optional[np.ndarray]:
    d = ds.data
    for prefix in prefixes:
        keys = [f"{prefix}[0]", f"{prefix}[1]", f"{prefix}[2]"]
        if all(k in d for k in keys):
            return np.column_stack([d[k] for k in keys]).astype(float)
    return None




def ulog_quaternion(ds, prefixes: Sequence[str]) -> Optional[np.ndarray]:
    """Return PX4 quaternion as [w, x, y, z]."""
    d = ds.data
    for prefix in prefixes:
        keys = [f"{prefix}[0]", f"{prefix}[1]", f"{prefix}[2]", f"{prefix}[3]"]
        if all(k in d for k in keys):
            q = np.column_stack([d[k] for k in keys]).astype(float)
            n = np.linalg.norm(q, axis=1, keepdims=True)
            good = n[:, 0] > EPS
            q[good] /= n[good]
            q[~good] = np.nan
            return q
    return None


def quaternion_to_rpy(q: np.ndarray) -> np.ndarray:
    """Convert [w,x,y,z] quaternions to roll/pitch/yaw in radians."""
    q = np.asarray(q, dtype=float)
    w, x, y, z = q[:, 0], q[:, 1], q[:, 2], q[:, 3]

    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = np.arctan2(sinr_cosp, cosr_cosp)

    sinp = 2.0 * (w * y - z * x)
    pitch = np.arcsin(np.clip(sinp, -1.0, 1.0))

    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = np.arctan2(siny_cosp, cosy_cosp)

    # Unwrap roll/yaw to avoid artificial +/-pi jumps in correlation.
    roll = np.unwrap(roll)
    yaw = np.unwrap(yaw)
    return np.column_stack([roll, pitch, yaw])


def actuator_controls(ds) -> Tuple[np.ndarray, List[str]]:
    d = ds.data
    items = []
    for k in d.keys():
        m = re.fullmatch(r"control\[(\d+)\]", k)
        if m:
            items.append((int(m.group(1)), k))
    items.sort()
    if not items:
        return np.empty((len(dataset_time(ds)), 0)), []
    keys = [k for _, k in items]
    arr = np.column_stack([d[k] for k in keys]).astype(float)
    return arr, keys


def longest_active_window(t: np.ndarray, active: np.ndarray, gap_tol: float) -> Optional[Tuple[float, float]]:
    idx = np.where(active)[0]
    if idx.size < 2:
        return None
    active_t = t[idx]
    breaks = np.where(np.diff(active_t) > gap_tol)[0]
    starts = np.r_[0, breaks + 1]
    ends = np.r_[breaks, len(active_t) - 1]
    best = None
    best_dur = -1.0
    for s, e in zip(starts, ends):
        a, b = float(active_t[s]), float(active_t[e])
        if b - a > best_dur:
            best = (a, b)
            best_dur = b - a
    return best


def infer_flight_window(ulog, cfg: dict) -> Optional[Tuple[float, float]]:
    ds = get_dataset(ulog, "actuator_motors")
    if ds is None:
        return None
    t = dataset_time(ds)
    u, _ = actuator_controls(ds)
    if u.shape[1] == 0:
        return None
    valid_frac = np.mean(np.isfinite(u), axis=0)
    cols = np.where(valid_frac > 0.3)[0]
    if cols.size == 0:
        return None
    mean_u = np.nanmean(np.abs(u[:, cols]), axis=1)
    active = np.isfinite(mean_u) & (mean_u > float(cfg.get("actuator_active_threshold", 0.05)))
    return longest_active_window(t, active, float(cfg.get("actuator_gap_tolerance_s", 0.5)))


def window_mask(t: np.ndarray, window: Optional[Tuple[float, float]]) -> np.ndarray:
    if window is None:
        return np.ones(len(t), dtype=bool)
    return (t >= window[0]) & (t <= window[1])


def _corrcoef_safe(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    good = np.isfinite(a) & np.isfinite(b)
    if np.count_nonzero(good) < 20:
        return float("nan")
    a = a[good] - np.mean(a[good])
    b = b[good] - np.mean(b[good])
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    if den <= EPS:
        return float("nan")
    return float(np.dot(a, b) / den)




def analyze_attitude_delay(ulog, window, cfg: dict, warnings: List[str]):
    """Estimate Roll/Pitch attitude response delay without scoring error magnitude.

    For each sufficiently excited Roll/Pitch axis, search tau such that
    actual_attitude(t) best correlates with desired_attitude(t - tau).
    Positive tau therefore means the actual attitude lags the setpoint.

    The scored metric is the maximum absolute delay among the active Roll/Pitch
    axes. Yaw is intentionally excluded from the score because course yaw
    strategies may differ.
    """
    actual_ds = get_dataset(ulog, "vehicle_attitude")
    desired_ds = get_dataset(ulog, "vehicle_attitude_setpoint")
    if actual_ds is None or desired_ds is None:
        warnings.append("Missing vehicle_attitude or vehicle_attitude_setpoint; attitude delay unavailable.")
        return {}, {}

    qa = ulog_quaternion(actual_ds, ["q"])
    qd = ulog_quaternion(desired_ds, ["q_d", "q"])
    if qa is None or qd is None:
        warnings.append("Attitude quaternion fields are incomplete; attitude delay unavailable.")
        return {}, {}

    actual = quaternion_to_rpy(qa)
    desired = quaternion_to_rpy(qd)
    ta = dataset_time(actual_ds)
    td = dataset_time(desired_ds)

    ma = window_mask(ta, window)
    ta, actual = ta[ma], actual[ma]
    good = finite_rows(ta, actual)
    ta, actual = ta[good], actual[good]
    if len(ta) < 100 or len(td) < 50:
        warnings.append("Too few attitude samples for reliable attitude-delay estimation.")
        return {}, {}

    t0 = max(float(ta[0]), float(td[0]))
    t1 = min(float(ta[-1]), float(td[-1]))
    md = (td >= t0) & (td <= t1)
    if np.count_nonzero(md) < 30:
        warnings.append("Insufficient overlapping attitude-setpoint samples for attitude-delay estimation.")
        return {}, {}

    # Only Roll/Pitch participate in the scored attitude delay.
    desired_std = np.nanstd(desired[md, :2], axis=0)
    min_std = float(cfg.get("attitude_delay_min_setpoint_std_rad", 0.02))
    active_axes = np.where(desired_std >= min_std)[0]
    if active_axes.size == 0:
        warnings.append(
            "Roll/Pitch attitude setpoints contain too little excitation for delay estimation; "
            "use a flight segment with attitude motion."
        )
        return {}, {}

    max_s = float(cfg.get("attitude_delay_search_max_s", cfg.get("delay_search_max_s", 0.50)))
    step_s = float(cfg.get("attitude_delay_search_step_s", cfg.get("delay_search_step_s", 0.002)))
    if max_s <= 0 or step_s <= 0:
        raise ValueError("attitude_delay_search_max_s and attitude_delay_search_step_s must be positive")
    taus = np.arange(-max_s, max_s + 0.5 * step_s, step_s)

    axis_scores = np.full((len(taus), 2), np.nan, dtype=float)
    for i, tau in enumerate(taus):
        tq = ta - tau
        valid = (tq >= td[0]) & (tq <= td[-1])
        if np.count_nonzero(valid) < 50:
            continue
        av = actual[valid, :2]
        di = interp_columns(tq[valid], td, desired[:, :2])
        for ax in active_axes:
            axis_scores[i, ax] = _corrcoef_safe(av[:, ax], di[:, ax])

    axis_names = ["roll", "pitch"]
    axis_delays = {}
    for ax in active_axes:
        col = axis_scores[:, ax]
        if np.any(np.isfinite(col)):
            j = int(np.nanargmax(col))
            axis_delays[ax] = float(taus[j])

    if not axis_delays:
        warnings.append("Could not estimate Roll/Pitch attitude response delay from correlation.")
        return {}, {}

    scored_delay = max(abs(v) for v in axis_delays.values())
    metrics = {
        "delay.attitude_delay_abs_s": float(scored_delay),
        "debug.attitude_delay_active_axis_count": float(len(axis_delays)),
    }
    for ax, tau in axis_delays.items():
        metrics[f"debug.attitude_{axis_names[ax]}_delay_signed_s"] = tau
        col = axis_scores[:, ax]
        j = int(np.nanargmax(col))
        metrics[f"debug.attitude_{axis_names[ax]}_delay_peak_correlation"] = float(col[j])

    # Plot original signals plus one correlation curve per active Roll/Pitch axis.
    valid0 = (ta >= td[0]) & (ta <= td[-1])
    tplot = ta[valid0]
    aplot = actual[valid0, :2]
    dplot = interp_columns(tplot, td, desired[:, :2])
    series = {
        "att_delay_t": tplot - tplot[0],
        "actual_attitude_rp": aplot,
        "desired_attitude_rp": dplot,
        "att_delay_search_s": taus,
        "att_delay_axis_correlation": axis_scores,
        "att_delay_active_axes": np.array(sorted(axis_delays.keys()), dtype=int),
        "att_delay_scored_abs_s": np.array([scored_delay]),
    }
    for ax, tau in axis_delays.items():
        series[f"att_delay_{axis_names[ax]}_signed_s"] = np.array([tau])
    return metrics, series


def analyze_rate_delay(ulog, window, cfg: dict, warnings: List[str]):
    """Estimate body-rate response delay without scoring tracking-error magnitude.

    The estimator searches tau so that actual_rate(t) best correlates with
    desired_rate(t - tau). Therefore a positive tau means the actual response
    lags the setpoint by approximately tau seconds.
    """
    actual_ds = get_dataset(ulog, "vehicle_angular_velocity")
    desired_ds = get_dataset(ulog, "vehicle_rates_setpoint")
    if actual_ds is None or desired_ds is None:
        warnings.append("Missing vehicle_angular_velocity or vehicle_rates_setpoint; delay unavailable.")
        return {}, {}

    actual = ulog_vector(actual_ds, ["xyz"])
    dd = desired_ds.data
    if actual is None or not all(k in dd for k in ["roll", "pitch", "yaw"]):
        warnings.append("Angular-rate actual/setpoint fields are incomplete; delay unavailable.")
        return {}, {}
    desired = np.column_stack([dd["roll"], dd["pitch"], dd["yaw"]]).astype(float)

    ta = dataset_time(actual_ds)
    td = dataset_time(desired_ds)
    ma = window_mask(ta, window)
    ta, actual = ta[ma], actual[ma]
    good = finite_rows(ta, actual)
    ta, actual = ta[good], actual[good]
    if len(ta) < 100 or len(td) < 50:
        warnings.append("Too few angular-rate samples for reliable delay estimation.")
        return {}, {}

    # Determine which axes have enough setpoint excitation in the analysis window.
    t0 = max(float(ta[0]), float(td[0]))
    t1 = min(float(ta[-1]), float(td[-1]))
    md = (td >= t0) & (td <= t1)
    if np.count_nonzero(md) < 30:
        warnings.append("Insufficient overlapping rate-setpoint samples for delay estimation.")
        return {}, {}
    desired_std = np.nanstd(desired[md], axis=0)
    min_std = float(cfg.get("delay_min_setpoint_std_rad_s", 0.03))
    active_axes = np.where(desired_std >= min_std)[0]
    if active_axes.size == 0:
        warnings.append(
            "Angular-rate setpoints contain too little excitation for delay estimation; "
            "use a flight segment with roll/pitch/yaw motion."
        )
        return {}, {}

    max_s = float(cfg.get("delay_search_max_s", 0.30))
    step_s = float(cfg.get("delay_search_step_s", 0.002))
    if max_s <= 0 or step_s <= 0:
        raise ValueError("delay_search_max_s and delay_search_step_s must be positive")
    taus = np.arange(-max_s, max_s + 0.5 * step_s, step_s)

    axis_names = ["roll", "pitch", "yaw"]
    weights = desired_std[active_axes]
    weights = weights / np.sum(weights)
    combined_scores = np.full(len(taus), np.nan, dtype=float)
    axis_scores = np.full((len(taus), 3), np.nan, dtype=float)

    for i, tau in enumerate(taus):
        # Positive tau: compare actual(t) against an earlier setpoint desired(t-tau).
        tq = ta - tau
        valid = (tq >= td[0]) & (tq <= td[-1])
        if np.count_nonzero(valid) < 50:
            continue
        tqv = tq[valid]
        av = actual[valid]
        di = interp_columns(tqv, td, desired)
        vals = []
        vals_w = []
        for ax in active_axes:
            c = _corrcoef_safe(av[:, ax], di[:, ax])
            axis_scores[i, ax] = c
            if np.isfinite(c):
                vals.append(c)
                vals_w.append(weights[np.where(active_axes == ax)[0][0]])
        if vals:
            vals_w = np.asarray(vals_w, dtype=float)
            vals_w /= np.sum(vals_w)
            combined_scores[i] = float(np.dot(vals_w, np.asarray(vals)))

    if not np.any(np.isfinite(combined_scores)):
        warnings.append("Could not estimate angular-rate response delay from correlation.")
        return {}, {}

    best_i = int(np.nanargmax(combined_scores))
    best_tau = float(taus[best_i])
    metrics = {
        "delay.angular_rate_delay_abs_s": abs(best_tau),
        "debug.angular_rate_delay_signed_s": best_tau,
        "debug.delay_peak_correlation": float(combined_scores[best_i]),
        "debug.delay_active_axis_count": float(active_axes.size),
    }

    # Per-axis delays are diagnostics only; they are not separately scored.
    for ax, name in enumerate(axis_names):
        if ax not in active_axes:
            continue
        col = axis_scores[:, ax]
        if np.any(np.isfinite(col)):
            j = int(np.nanargmax(col))
            metrics[f"debug.{name}_delay_signed_s"] = float(taus[j])
            metrics[f"debug.{name}_delay_peak_correlation"] = float(col[j])

    # Plot only actual/setpoint signals and the correlation-vs-delay curve; no error curve.
    valid0 = (ta >= td[0]) & (ta <= td[-1])
    tplot = ta[valid0]
    aplot = actual[valid0]
    dplot = interp_columns(tplot, td, desired)
    series = {
        "delay_t": tplot - tplot[0],
        "actual_rate": aplot,
        "desired_rate": dplot,
        "delay_search_s": taus,
        "delay_correlation": combined_scores,
        "delay_best_signed_s": np.array([best_tau]),
        "delay_active_axes": active_axes.astype(int),
    }
    return metrics, series


def fifo_axis_keys(d: dict, axis: str) -> List[str]:
    out = []
    for k in d.keys():
        m = re.fullmatch(rf"{re.escape(axis)}\[(\d+)\]", k)
        if m:
            out.append((int(m.group(1)), k))
    out.sort()
    return [k for _, k in out]


def extract_gyro_fifo(ulog, window, warnings: List[str]):
    ds = get_dataset(ulog, "sensor_gyro_fifo")
    if ds is None:
        return None
    d = ds.data
    xk, yk, zk = fifo_axis_keys(d, "x"), fifo_axis_keys(d, "y"), fifo_axis_keys(d, "z")
    ncols = min(len(xk), len(yk), len(zk))
    if ncols == 0:
        return None

    tmsg = dataset_time(ds)
    mm = window_mask(tmsg, window)
    idxs = np.where(mm)[0]
    if idxs.size == 0:
        return None

    xs, ys, zs = [], [], []
    dts = []
    for i in idxs:
        n = ncols
        if "samples" in d:
            try:
                n = min(ncols, max(0, int(d["samples"][i])))
            except Exception:
                n = ncols
        if n <= 0:
            continue
        scale = float(d["scale"][i]) if "scale" in d else 1.0
        xv_raw = np.array([d[k][i] for k in xk[:n]], dtype=float)
        yv_raw = np.array([d[k][i] for k in yk[:n]], dtype=float)
        zv_raw = np.array([d[k][i] for k in zk[:n]], dtype=float)
        xs.append(xv_raw * scale)
        ys.append(yv_raw * scale)
        zs.append(zv_raw * scale)
        if "dt" in d and np.isfinite(d["dt"][i]) and float(d["dt"][i]) > 0:
            dts.append(float(d["dt"][i]))

    if not xs:
        return None
    gyro = np.column_stack([np.concatenate(xs), np.concatenate(ys), np.concatenate(zs)])
    good = finite_rows(gyro)
    gyro = gyro[good]

    fs = float("nan")
    if dts:
        fs = 1e6 / float(np.median(dts))
    if not np.isfinite(fs) or fs < 10:
        warnings.append("Could not determine sensor_gyro_fifo sample rate; using fallback if available.")
        return None

    return gyro, fs


def fallback_gyro(ulog, window):
    ds = get_dataset(ulog, "vehicle_angular_velocity")
    if ds is None:
        return None
    xyz = ulog_vector(ds, ["xyz"])
    if xyz is None:
        return None
    t = dataset_time(ds)
    m = window_mask(t, window)
    t, xyz = t[m], xyz[m]
    good = finite_rows(t, xyz)
    t, xyz = t[good], xyz[good]
    if len(t) < 50:
        return None
    dt = np.median(np.diff(t))
    if dt <= 0:
        return None
    return xyz, 1.0 / dt, None


def band_rms_psd(x: np.ndarray, fs: float, band: Sequence[float]):
    x = np.asarray(x, dtype=float)
    if x.ndim == 1:
        x = x[:, None]
    if len(x) < 64 or not np.isfinite(fs) or fs <= 0:
        return float("nan"), None, None

    nperseg = min(4096, len(x))
    f, pxx = signal.welch(
        x,
        fs=fs,
        axis=0,
        nperseg=nperseg,
        detrend="constant",
        scaling="density",
    )
    lo = float(band[0])
    hi = min(float(band[1]), 0.45 * fs)
    mask = (f >= lo) & (f <= hi)
    if np.count_nonzero(mask) < 2:
        return float("nan"), f, np.nanmean(pxx, axis=1)
    power = np.trapz(pxx[mask], f[mask], axis=0)
    axis_rms = np.sqrt(np.maximum(power, 0.0))
    return float(np.mean(axis_rms)), f, np.nanmean(pxx, axis=1)


def analyze_vibration(ulog, window, cfg: dict, warnings: List[str]):
    metrics, series = {}, {}
    fifo = extract_gyro_fifo(ulog, window, warnings)
    if fifo is not None:
        gyro, fs = fifo
        source = "sensor_gyro_fifo"
    else:
        fb = fallback_gyro(ulog, window)
        if fb is None:
            warnings.append("No usable gyro signal for vibration analysis.")
            return metrics, series
        gyro, fs, _ = fb
        source = "vehicle_angular_velocity_fallback"
        warnings.append("Vibration PSD is using vehicle_angular_velocity fallback; high-frequency bandwidth is limited.")

    val, f, pxx = band_rms_psd(gyro, fs, cfg.get("gyro_vibration_band_hz", [80.0, 900.0]))
    metrics["vibration.gyro_hf_rms_rad_s"] = val
    metrics["debug.gyro_sample_rate_hz"] = float(fs)
    metrics["debug.gyro_source_fifo"] = 1.0 if source == "sensor_gyro_fifo" else 0.0
    series["gyro_freq_hz"] = f if f is not None else np.array([])
    series["gyro_psd_mean"] = pxx if pxx is not None else np.array([])
    return metrics, series


def analyze_actuator(ulog, window, cfg: dict, warnings: List[str]):
    ds = get_dataset(ulog, "actuator_motors")
    if ds is None:
        warnings.append("Missing actuator_motors.")
        return {}, {}
    t = dataset_time(ds)
    u, _ = actuator_controls(ds)
    if u.shape[1] == 0:
        warnings.append("actuator_motors has no control[] fields.")
        return {}, {}
    m = window_mask(t, window)
    t, u = t[m], u[m]
    if len(t) < 50:
        warnings.append("Too few actuator samples in flight window.")
        return {}, {}

    valid_frac = np.mean(np.isfinite(u), axis=0)
    cols = np.where(valid_frac > 0.3)[0]
    if cols.size == 0:
        return {}, {}
    u = u[:, cols]
    uu = u.copy()
    for j in range(uu.shape[1]):
        good = np.isfinite(uu[:, j])
        if np.count_nonzero(good) >= 2:
            uu[:, j] = np.interp(t, t[good], uu[good, j])

    dt = np.median(np.diff(t))
    fs = 1.0 / dt if dt > 0 else float("nan")
    hf, f, pxx = band_rms_psd(uu, fs, cfg.get("actuator_hf_band_hz", [20.0, 150.0]))

    metrics = {
        "vibration.actuator_hf_rms": hf,
        "debug.actuator_sample_rate_hz": float(fs),
        "debug.actuator_max_abs": float(np.nanmax(np.abs(uu))),
        "debug.motor_count": float(uu.shape[1]),
    }
    series = {
        "actuator_t": t - t[0],
        "actuator": uu,
        "actuator_freq_hz": f if f is not None else np.array([]),
        "actuator_psd_mean": pxx if pxx is not None else np.array([]),
    }
    return metrics, series


def analyze_ulog(ulg_path: str, cfg: dict) -> ULogResult:
    try:
        from pyulog import ULog
    except ImportError as exc:
        raise RuntimeError("Cannot import pyulog. Install it with: pip3 install pyulog") from exc

    warnings: List[str] = []
    ulog = ULog(ulg_path)
    window = infer_flight_window(ulog, cfg) if cfg.get("infer_flight_from_actuator", True) else None
    if window is None:
        warnings.append("Could not infer motor-active flight window; using all ULog samples.")

    metrics: Dict[str, float] = {}
    series: Dict[str, np.ndarray] = {}

    m, s = analyze_attitude_delay(ulog, window, cfg, warnings)
    metrics.update(m)
    series.update(s)

    m, s = analyze_rate_delay(ulog, window, cfg, warnings)
    metrics.update(m)
    series.update(s)

    m, s = analyze_vibration(ulog, window, cfg, warnings)
    metrics.update(m)
    series.update(s)

    m, s = analyze_actuator(ulog, window, cfg, warnings)
    metrics.update(m)
    series.update(s)

    if window is not None:
        metrics["debug.ulog_flight_duration_s"] = float(window[1] - window[0])

    return ULogResult(metrics=metrics, series=series, warnings=warnings, flight_window=window)


def lower_is_better_score(value: float, excellent: float, fail: float, weight: float) -> float:
    if not np.isfinite(value):
        return float("nan")
    if value <= excellent:
        return weight
    if value >= fail:
        return 0.0
    return weight * (fail - value) / (fail - excellent)


def binary_score(value: float, weight: float) -> float:
    if not np.isfinite(value):
        return float("nan")
    return weight if value >= 0.5 else 0.0


def flatten_scoring_config(scoring: dict):
    rows = []
    for category, items in scoring.items():
        for metric_name, rule in items.items():
            rows.append((f"{category}.{metric_name}", rule))
    return rows


def calculate_scores(metrics: Dict[str, float], cfg: dict):
    rows = []
    total = 0.0
    max_total = 0.0
    categories = {}
    for key, rule in flatten_scoring_config(cfg["scoring"]):
        weight = float(rule["weight"])
        max_total += weight
        value = float(metrics.get(key, float("nan")))
        typ = str(rule.get("type", "lower_is_better"))
        if typ == "lower_is_better":
            score = lower_is_better_score(value, float(rule["excellent"]), float(rule["fail"]), weight)
        elif typ == "binary":
            score = binary_score(value, weight)
        else:
            raise ValueError(f"Unknown scoring type {typ} for {key}")
        missing = not np.isfinite(score)
        effective = 0.0 if missing else float(score)
        total += effective
        category = key.split(".", 1)[0]
        categories.setdefault(category, [0.0, 0.0])
        categories[category][0] += effective
        categories[category][1] += weight
        rows.append({
            "metric": key,
            "value": None if not np.isfinite(value) else value,
            "score": effective,
            "max_score": weight,
            "missing": missing,
            "rule": rule,
        })
    normalized = 100.0 * total / max_total if max_total > 0 else 0.0
    return {
        "total": total,
        "max_total": max_total,
        "normalized_100": normalized,
        "rows": rows,
        "categories": {k: {"score": v[0], "max_score": v[1]} for k, v in categories.items()},
    }


def grade_for_score(score_100: float, meta: dict) -> str:
    if score_100 >= float(meta.get("grade_A", 90)):
        return "A"
    if score_100 >= float(meta.get("grade_B", 80)):
        return "B"
    if score_100 >= float(meta.get("grade_C", 70)):
        return "C"
    if score_100 >= float(meta.get("grade_D", 60)):
        return "D"
    return "F"


def save_plot(path: Path):
    plt.tight_layout()
    plt.savefig(path, dpi=160, bbox_inches="tight")
    plt.close()


def make_plots(output: Path, s: dict):
    if "att_delay_t" in s:
        plt.figure(figsize=(9, 5.5))
        labels = ["Roll", "Pitch"]
        active = set(int(x) for x in s.get("att_delay_active_axes", []))
        for j, name in enumerate(labels):
            if active and j not in active:
                continue
            plt.plot(s["att_delay_t"], np.degrees(s["desired_attitude_rp"][:, j]), "--", label=f"{name} setpoint")
            plt.plot(s["att_delay_t"], np.degrees(s["actual_attitude_rp"][:, j]), label=f"{name} actual")
        delay_ms = 1000.0 * float(s["att_delay_scored_abs_s"][0])
        plt.xlabel("Time [s]")
        plt.ylabel("Attitude [deg]")
        plt.title(f"Roll/Pitch attitude response (scored delay = {delay_ms:.1f} ms)")
        plt.grid(True)
        plt.legend(ncol=2)
        save_plot(output / "attitude_response_delay.png")

        plt.figure(figsize=(8, 4.5))
        for j, name in enumerate(labels):
            if active and j not in active:
                continue
            corr = s["att_delay_axis_correlation"][:, j]
            plt.plot(1000.0 * s["att_delay_search_s"], corr, label=f"{name} correlation")
            key = f"att_delay_{name.lower()}_signed_s"
            if key in s:
                dms = 1000.0 * float(s[key][0])
                plt.axvline(dms, linestyle="--", label=f"{name} best {dms:.1f} ms")
        plt.xlabel("Candidate delay [ms]")
        plt.ylabel("Correlation")
        plt.title("Attitude delay search")
        plt.grid(True)
        plt.legend()
        save_plot(output / "attitude_delay_correlation.png")

    if "delay_t" in s:
        plt.figure(figsize=(9, 6))
        labels = ["Roll", "Pitch", "Yaw"]
        active = set(int(x) for x in s.get("delay_active_axes", []))
        for j, name in enumerate(labels):
            if active and j not in active:
                continue
            plt.plot(s["delay_t"], s["desired_rate"][:, j], "--", label=f"{name} setpoint")
            plt.plot(s["delay_t"], s["actual_rate"][:, j], label=f"{name} actual")
        delay_ms = 1000.0 * float(s["delay_best_signed_s"][0])
        plt.xlabel("Time [s]")
        plt.ylabel("Angular rate [rad/s]")
        plt.title(f"Angular-rate response (estimated delay = {delay_ms:.1f} ms)")
        plt.grid(True)
        plt.legend(ncol=2)
        save_plot(output / "rate_response_delay.png")

        plt.figure(figsize=(8, 4.5))
        plt.plot(1000.0 * s["delay_search_s"], s["delay_correlation"], label="Normalized correlation")
        plt.axvline(delay_ms, linestyle="--", label=f"Best delay {delay_ms:.1f} ms")
        plt.xlabel("Candidate delay [ms]")
        plt.ylabel("Correlation")
        plt.title("Angular-rate delay search")
        plt.grid(True)
        plt.legend()
        save_plot(output / "delay_correlation.png")

    if "gyro_freq_hz" in s and len(s["gyro_freq_hz"]):
        plt.figure(figsize=(8, 4.5))
        plt.semilogy(s["gyro_freq_hz"], s["gyro_psd_mean"], label="Mean XYZ gyro PSD")
        plt.xlabel("Frequency [Hz]")
        plt.ylabel("PSD [(rad/s)^2/Hz]")
        plt.title("Gyroscope vibration spectrum")
        plt.grid(True)
        plt.legend()
        save_plot(output / "gyro_psd.png")

    if "actuator_t" in s:
        u = s["actuator"]
        plt.figure(figsize=(8, 4.5))
        for j in range(min(u.shape[1], 8)):
            plt.plot(s["actuator_t"], u[:, j], label=f"Motor {j+1}")
        plt.xlabel("Time [s]")
        plt.ylabel("Normalized control")
        plt.title("Actuator motor output")
        plt.grid(True)
        plt.legend(ncol=2)
        save_plot(output / "actuator_output.png")

    if "actuator_freq_hz" in s and len(s["actuator_freq_hz"]):
        plt.figure(figsize=(8, 4.5))
        plt.semilogy(s["actuator_freq_hz"], s["actuator_psd_mean"], label="Mean motor-command PSD")
        plt.xlabel("Frequency [Hz]")
        plt.ylabel("PSD [control^2/Hz]")
        plt.title("Actuator high-frequency spectrum")
        plt.grid(True)
        plt.legend()
        save_plot(output / "actuator_psd.png")


def unit_for_metric(key: str) -> str:
    if key.endswith("_rad_s"):
        return "rad/s"
    if key.endswith("_deg"):
        return "deg"
    if key.endswith("_s"):
        return "s"
    if key.endswith("_fraction"):
        return "fraction"
    return ""


def write_csv(output: Path, score_result: dict):
    with open(output / "score_summary.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value", "unit", "score", "max_score", "missing"])
        for r in score_result["rows"]:
            w.writerow([
                r["metric"],
                "" if r["value"] is None else f"{r['value']:.8g}",
                unit_for_metric(r["metric"]),
                f"{r['score']:.3f}",
                f"{r['max_score']:.3f}",
                int(r["missing"]),
            ])


def jsonable(obj):
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, dict):
        return {k: jsonable(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [jsonable(v) for v in obj]
    if isinstance(obj, tuple):
        return [jsonable(v) for v in obj]
    return obj


def print_summary(metrics: dict, scores: dict, grade: str, warnings: List[str], payload: Optional[float]):
    print("=" * 68)
    print(" PX4 ULog Response Delay & Vibration Evaluation")
    print("=" * 68)
    if payload is not None:
        print(f"Payload record: {payload:.1f} g")

    print("\nCategory scores")
    for category, s in scores["categories"].items():
        print(f"  {category:22s} {s['score']:7.2f} / {s['max_score']:.2f}")

    print("\nKey metrics")
    for k in [
        "delay.attitude_delay_abs_s",
        "debug.attitude_roll_delay_signed_s",
        "debug.attitude_pitch_delay_signed_s",
        "delay.angular_rate_delay_abs_s",
        "debug.angular_rate_delay_signed_s",
        "debug.roll_delay_signed_s",
        "debug.pitch_delay_signed_s",
        "debug.yaw_delay_signed_s",
        "debug.delay_peak_correlation",
        "vibration.gyro_hf_rms_rad_s",
        "vibration.actuator_hf_rms",
        "debug.ulog_flight_duration_s",
    ]:
        if k in metrics and np.isfinite(metrics[k]):
            print(f"  {k:46s} {metrics[k]:.6g} {unit_for_metric(k)}")

    print("\n" + "-" * 68)
    print(f"ULog Score:           {scores['total']:.2f} / {scores['max_total']:.2f}")
    print(f"ULog Grade:            {grade}")
    print("NOTE: This is a standalone ULog score. Do not assume it matches any ROS bag flight.")

    missing = [r["metric"] for r in scores["rows"] if r["missing"]]
    if missing:
        print("Missing scored metrics:")
        for k in missing:
            print(f"  - {k}")
    if warnings:
        print("Warnings:")
        for x in warnings:
            print(f"  - {x}")
    print("=" * 68)


def main():
    ap = argparse.ArgumentParser(description="Standalone PX4 ULog response-delay and vibration scorer")
    ap.add_argument("--ulg", required=True, help="PX4 .ulg file")
    ap.add_argument("--config", default="ulog_scoring.yaml", help="ULog scoring YAML")
    ap.add_argument("--output", default="ulog_score_result", help="Output directory")
    ap.add_argument("--payload", type=float, default=None, help="Payload mass in grams, record only")
    ap.add_argument("--no-plots", action="store_true")
    args = ap.parse_args()

    cfg = load_yaml(args.config)
    configured_max = float(cfg.get("meta", {}).get("max_score", 100.0))
    weight_sum = sum(float(rule["weight"]) for _, rule in flatten_scoring_config(cfg["scoring"]))
    if abs(weight_sum - configured_max) > 1e-6:
        raise ValueError(f"Scoring weights sum to {weight_sum}, but meta.max_score is {configured_max}")
    out = ensure_dir(args.output)
    ur = analyze_ulog(args.ulg, cfg.get("ulog", {}))
    metrics = ur.metrics
    scores = calculate_scores(metrics, cfg)
    grade = grade_for_score(scores["normalized_100"], cfg.get("meta", {}))

    if not args.no_plots:
        make_plots(out, ur.series)
    write_csv(out, scores)

    result = {
        "analysis_type": "px4_ulog_response_delay_vibration",
        "input": {
            "ulg": os.path.abspath(args.ulg),
            "config": os.path.abspath(args.config),
            "payload_g": args.payload,
        },
        "flight_window_s": ur.flight_window,
        "metrics": metrics,
        "score": {
            "raw": scores["total"],
            "raw_max": scores["max_total"],
            "normalized_100": scores["normalized_100"],
            "grade": grade,
            "categories": scores["categories"],
            "rows": scores["rows"],
        },
        "warnings": ur.warnings,
    }
    with open(out / "score_summary.json", "w", encoding="utf-8") as f:
        json.dump(jsonable(result), f, ensure_ascii=False, indent=2)

    print_summary(metrics, scores, grade, ur.warnings, args.payload)
    print(f"Results written to: {out.resolve()}")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        eprint("ERROR:", exc)
        if os.environ.get("UAV_SCORE_DEBUG", "0") == "1":
            traceback.print_exc()
        sys.exit(2)
