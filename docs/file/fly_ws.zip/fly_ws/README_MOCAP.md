# novok_mocap（fly_ws）

动捕链路，对齐原 `8fly_ws` 的 `run_eight_mocap.sh` 用法：

```text
vrpn_client_ros (sample.launch)
  -> /vrpn_client_node/<tracker>/pose|twist
vrpn_process (fusion_odom.launch)
  -> /MVD/odom
px4ctrl / trajectory 订阅 /MVD/odom
```

## 依赖

```bash
sudo apt-get install ros-noetic-vrpn
```

## 刚体名

默认 tracker=`MVD`（Motive/Nokov 里刚体名需一致）。改名：

```bash
roslaunch vrpn_process fusion_odom.launch tracker:=YourName
```

## 编译

```bash
cd <fly_ws>
catkin_make -DCATKIN_WHITELIST_PACKAGES="vrpn_client_ros;vrpn_process"
```
