# fly_ws

实飞工作空间（对齐原 8fly_ws `run_eight_mocap.sh`）。

## 目录

- `sh_file/run_mocap.sh` — 一键：mavros + VRPN + `/MVD/odom` + px4ctrl + trajectory
- `src/novok_mocap/` — `vrpn_client_ros` + `vrpn_process`
- `src/px4ctrl/` — 控制器（mocap 用 `/MVD/odom`）
- `src/8fly/` — trajectory / traj_server（`shape:4` 穿环）

## 编译

```bash
cd /home/diffbot/fly_ws   # 或板上 ~/fly_ws
source /opt/ros/noetic/setup.bash
sudo apt-get install -y ros-noetic-vrpn
catkin_make
```

## 启动

```bash
./sh_file/run_mocap.sh
./sh_file/takeoff.sh
./sh_file/pub_trigger.sh
```

轨迹形状改 `src/8fly/src/trajectory/parameters/traj.yaml` 的 `shape`（0 八字 / 4 穿环）。
动捕服务器 IP：`roslaunch vrpn_client_ros sample.launch server:=x.x.x.x`
刚体名默认 `MVD`，与 Motive/Nokov 一致。
