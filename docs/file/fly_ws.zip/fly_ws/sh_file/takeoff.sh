#!/bin/bash
# Auto takeoff for px4ctrl or OMMPC (both subscribe /px4ctrl/takeoff_land).
# Require already running: mavros + odom + (px4ctrl OR mpc_ctrl).
# Height: px4ctrl yaml / OMMPC params_* takeoff_height (msg takeoff_hight optional).
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${WS_DIR}/devel/setup.bash"

rostopic pub -1 /px4ctrl/takeoff_land quadrotor_msgs/TakeoffLand "takeoff_land_cmd: 1"
