#!/bin/bash
# Equivalent of 8fly_ws/sh_file/run_eight_mocap.sh for fly_ws.
# Starts: mavros + PX4 stream rates + VRPN + fusion_odom + px4ctrl + fly_test_mocap
#
# Requires packages from novok_mocap (vrpn_client_ros, vrpn_process) in this workspace.
# Odom chain: VRPN -> fusion_odom -> /MVD/odom
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
cd "${WS_DIR}"

if [[ -f /opt/ros/noetic/setup.bash ]]; then
  # shellcheck source=/dev/null
  source /opt/ros/noetic/setup.bash
fi
# shellcheck source=/dev/null
source "${WS_DIR}/devel/setup.bash"

if ! rospack find vrpn_client_ros >/dev/null 2>&1 || ! rospack find vrpn_process >/dev/null 2>&1; then
  echo "[run_mocap] ERROR: vrpn_client_ros / vrpn_process not found"
  echo "  Expect packages under ${WS_DIR}/src/novok_mocap"
  echo "  sudo apt-get install -y ros-noetic-vrpn"
  echo "  cd ${WS_DIR} && catkin_make"
  exit 1
fi

echo 'l' | sudo -S chmod 777 /dev/tty* & sleep 1
roslaunch mavros px4.launch & sleep 2
rosrun mavros mavcmd long 511 31 5000 0 0 0 0 0 & sleep 1   # ATTITUDE_QUATERNION
rosrun mavros mavcmd long 511 105 5000 0 0 0 0 0 & sleep 1  # HIGHRES_IMU
rosrun mavros mavcmd long 511 83 5000 0 0 0 0 0 & sleep 1   # ATTITUDE_TARGET
rosrun mavros mavcmd long 511 147 5000 0 0 0 0 0 & sleep 1  # BATTERY_STATUS
rosrun mavros mavcmd long 511 106 5000 0 0 0 0 0 & sleep 1

roslaunch vrpn_client_ros sample.launch & sleep 5
roslaunch vrpn_process fusion_odom.launch & sleep 3
roslaunch px4ctrl run_ctrl_mocap.launch & sleep 3
roslaunch trajectory fly_test_mocap.launch & sleep 1
wait
