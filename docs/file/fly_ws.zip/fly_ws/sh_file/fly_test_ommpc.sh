#!/bin/bash
# Start OMMPC + 8fly traj_gen/traj_server (NOT px4ctrl).
#
# Usage: ./fly_test_ommpc.sh [gt|mocap]   (default: gt)
#
# --- SITL (gt) ---
#   1) roslaunch px4 mavros_posix_sitl.launch
#   2) ./sh_file/run_groundtruth.sh
#   3) ./sh_file/fly_test_ommpc.sh gt
#   4) ./sh_file/takeoff.sh
#   5) ./sh_file/pub_trigger.sh
#
# --- Real + mocap ---
#   1) ./sh_file/mavros.sh
#   2) ./sh_file/run_mocap.sh
#   3) ./sh_file/fly_test_ommpc.sh mocap
#   4) ./sh_file/takeoff.sh
#   5) ./sh_file/pub_trigger.sh
#
# IMPORTANT: do not run ./sh_file/fly_test.sh at the same time — both controllers
# publish /mavros/setpoint_raw/attitude.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${WS_DIR}/devel/setup.bash"

CTRL_MODE="${1:-gt}"
case "${CTRL_MODE}" in
  gt)
    CTRL_LAUNCH="run_ctrl_gt.launch"
    EXPECT_ODOM="/drone0/odom"
    PARAMS="params_sitl.yaml"
    ;;
  mocap)
    CTRL_LAUNCH="run_ctrl_mocap.launch"
    EXPECT_ODOM="/ekf/ekf_odom"
    PARAMS="params_mocap.yaml"
    ;;
  *)
    echo "Usage: $0 [gt|mocap]"
    exit 1
    ;;
esac

# Mutual exclusion: px4ctrl and OMMPC must not both drive the FCU.
if rosnode list 2>/dev/null | grep -qE '^/px4ctrl$'; then
  echo "[fly_test_ommpc] ERROR: /px4ctrl is already running."
  echo "  Stop fly_test.sh / px4ctrl before starting OMMPC."
  exit 1
fi
if rosnode list 2>/dev/null | grep -qE '^/mpc_ctrl$'; then
  echo "[fly_test_ommpc] ERROR: /mpc_ctrl is already running."
  echo "  Stop the existing OMMPC node first."
  exit 1
fi

echo "[fly_test_ommpc] launching OMMPC with ${CTRL_LAUNCH} (${PARAMS})"
echo "[fly_test_ommpc] odom: ${EXPECT_ODOM}"
echo "[fly_test_ommpc] cmd : /setpoints_cmd  (traj_server -> OMMPC ~pos_cmd)"
echo "[fly_test_ommpc] takeoff_land: /px4ctrl/takeoff_land  (reuse takeoff.sh/land.sh)"

roslaunch ommpc_controller "${CTRL_LAUNCH}" & sleep 2
roslaunch trajectory fly_test.launch odom_topic:="${EXPECT_ODOM}" cmd_topic:=/setpoints_cmd & sleep 1

echo "[fly_test_ommpc] verify:"
echo "  rosnode list | grep -E 'mpc_ctrl|px4ctrl'   # only mpc_ctrl"
echo "  rostopic info ${EXPECT_ODOM}                # sub includes /mpc_ctrl"
echo "  rostopic info /setpoints_cmd                # pub=traj_server, sub=mpc_ctrl"
echo "  rostopic echo /mpc/tracking_performance     # after hover: suggest_hover_percentage"

wait
