#!/bin/bash
# Start px4ctrl + fly_test trajectory.
#
# Usage: ./fly_test.sh [gt|mocap|vio|lio]   (default: gt for Gazebo SITL)
# Trajectory shape is selected in trajectory/parameters/traj.yaml (shape: 0..4).
# For OMMPC instead of px4ctrl: ./fly_test_ommpc.sh [gt|mocap]
#
# --- Full real mocap stack (same as 8fly run_eight_mocap.sh) ---
#   ./sh_file/run_mocap.sh
#   # already starts mavros + VRPN + /MVD/odom + px4ctrl + traj
#   Then: ./sh_file/takeoff.sh && ./sh_file/pub_trigger.sh
#
# --- SITL (gt) ---
#   1) roslaunch px4 mavros_posix_sitl.launch
#   2) ./sh_file/run_groundtruth.sh            # /drone0/odom
#   3) ./sh_file/fly_test.sh gt
#
# --- Split real flight (mavros already up) ---
#   1) ./sh_file/mavros.sh
#   2) VRPN+fusion already publishing /MVD/odom
#   3) ./sh_file/fly_test.sh mocap
#   4) RC: hover + command, sticks centered
#   5) ./sh_file/takeoff.sh
#   6) ./sh_file/pub_trigger.sh
#
# IMPORTANT: do not run with fly_test_ommpc.sh — both publish attitude setpoints.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${WS_DIR}/devel/setup.bash"

CTRL_MODE="${1:-gt}"
case "${CTRL_MODE}" in
  gt)
    CTRL_LAUNCH="run_ctrl_gt.launch"
    EXPECT_ODOM="/drone0/odom"
    ;;
  mocap)
    CTRL_LAUNCH="run_ctrl_mocap.launch"
    EXPECT_ODOM="/MVD/odom"
    ;;
  vio)
    CTRL_LAUNCH="run_ctrl_vio.launch"
    EXPECT_ODOM="/vins/imu_propagate"
    ;;
  lio)
    CTRL_LAUNCH="run_ctrl_lio.launch"
    EXPECT_ODOM="/ekf/ekf_odom"
    ;;
  *)
    echo "Usage: $0 [gt|mocap|vio|lio]"
    exit 1
    ;;
esac

if rosnode list 2>/dev/null | grep -qE '^/mpc_ctrl$'; then
  echo "[fly_test] ERROR: /mpc_ctrl (OMMPC) is already running."
  echo "  Stop fly_test_ommpc.sh before starting px4ctrl."
  exit 1
fi

echo "[fly_test] launching px4ctrl with ${CTRL_LAUNCH}"
echo "[fly_test] odom: ${EXPECT_ODOM}"
echo "[fly_test] cmd : /setpoints_cmd"
echo "[fly_test] traj params: trajectory/parameters/traj.yaml  (set shape: 4 for rings)"

roslaunch px4ctrl "${CTRL_LAUNCH}" & sleep 2
roslaunch trajectory fly_test.launch odom_topic:="${EXPECT_ODOM}" cmd_topic:=/setpoints_cmd & sleep 1

echo "[fly_test] verify:"
echo "  rostopic info ${EXPECT_ODOM}     # subscribers should include /px4ctrl and /traj_gen"
echo "  rostopic info /setpoints_cmd     # pub=traj_server, sub=px4ctrl"
echo "  rostopic echo /trajectory_vis -n 1   # after pub_trigger: planned path"
echo "  rostopic hz /mavros/imu/data     # ~200Hz"
echo "  rostopic hz ${EXPECT_ODOM}       # >=100Hz recommended"

wait
