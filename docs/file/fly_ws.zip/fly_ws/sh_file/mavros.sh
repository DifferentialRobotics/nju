#!/bin/bash
# Start MAVROS + raise key PX4 message rates (same order as real_planner Controller).
# Must be up before px4ctrl / takeoff.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${WS_DIR}/devel/setup.bash"

# Serial device: override with FCU_DEV if needed, e.g. FCU_DEV=/dev/ttyUSB0
FCU_DEV="${FCU_DEV:-/dev/ttyTHS0}"
if [[ -e "${FCU_DEV}" ]]; then
  sudo chmod 777 "${FCU_DEV}" || true
fi

roslaunch mavros px4.launch & sleep 3
# Raise stream rates: ATTITUDE_QUATERNION / ATTITUDE_TARGET / HIGHRES_IMU
rosrun mavros mavcmd long 511 31 5000 0 0 0 0 0 & sleep 1
rosrun mavros mavcmd long 511 83 5000 0 0 0 0 0 & sleep 1
rosrun mavros mavcmd long 511 105 5000 0 0 0 0 0 & sleep 1

wait
