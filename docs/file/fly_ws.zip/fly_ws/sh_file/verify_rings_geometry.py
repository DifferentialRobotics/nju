#!/usr/bin/env python3
"""Offline check: traj.yaml rings → one center waypoint per ring."""
import sys
from pathlib import Path

try:
    import yaml
except ImportError:
    print("Need PyYAML: pip install pyyaml", file=sys.stderr)
    sys.exit(1)

DEFAULT = Path(__file__).resolve().parents[1] / "src/8fly/src/trajectory/parameters/traj.yaml"


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT
    cfg = yaml.safe_load(path.read_text())
    if cfg.get("shape") != 4:
        print(f"note: shape={cfg.get('shape')} (use shape: 4 to enable rings at runtime)")
    assert "rings" in cfg and cfg["rings"], "traj.yaml missing rings list"
    return_home = bool(cfg.get("ringsReturnHome", False))

    wps = []
    for i, g in enumerate(cfg["rings"]):
        c = (float(g["x"]), float(g["y"]), float(g["z"]))
        wps.append(c)
        print(f"ring[{i}] c={c}")

    if return_home:
        Q = list(wps)
        if len(wps) >= 2:
            Q.extend(reversed(wps[:-1]))
        final = "init_pos (hover)"
    else:
        Q, final = wps[:-1], wps[-1]

    print(f"|wps_fwd|={len(wps)} |Q|={len(Q)} N={len(Q)+1} final={final}")
    print("Q =", Q)
    assert len(wps) == len(cfg["rings"])
    if return_home and len(wps) >= 2:
        assert Q == wps + list(reversed(wps[:-1]))
    print("GEOMETRY_OK (center-only)")


if __name__ == "__main__":
    main()
