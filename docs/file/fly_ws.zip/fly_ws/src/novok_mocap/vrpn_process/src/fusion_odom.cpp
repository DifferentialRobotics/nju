#include <vrpn_process/fusion_odom.h>

FusionOdom::~FusionOdom()
{
  delete sync_;
  delete pose_sub_;
  delete twist_sub_;
}

void FusionOdom::init(ros::NodeHandle &nh)
{
  nh.param<std::string>("pose_topic", pose_topic_, pose_topic_);
  nh.param<std::string>("twist_topic", twist_topic_, twist_topic_);
  nh.param<std::string>("odom_topic", odom_topic_, odom_topic_);
  nh.param<std::string>("frame_id", frame_id_, frame_id_);

  odom_pub_ = nh.advertise<nav_msgs::Odometry>(odom_topic_, 10);

  pose_sub_ = new message_filters::Subscriber<geometry_msgs::PoseStamped>(nh, pose_topic_, 10);
  twist_sub_ = new message_filters::Subscriber<geometry_msgs::TwistStamped>(nh, twist_topic_, 10);
  sync_ = new message_filters::Synchronizer<SyncPolicy>(SyncPolicy(20), *pose_sub_, *twist_sub_);
  sync_->registerCallback(boost::bind(&FusionOdom::callback, this, _1, _2));

  ROS_WARN("[fusion_odom] pose=%s twist=%s -> %s",
           pose_topic_.c_str(), twist_topic_.c_str(), odom_topic_.c_str());
}

void FusionOdom::callback(const geometry_msgs::PoseStampedConstPtr &pose,
                          const geometry_msgs::TwistStampedConstPtr &twist)
{
  nav_msgs::Odometry odom;
  odom.header.stamp = pose->header.stamp;
  odom.header.frame_id = frame_id_.empty() ? pose->header.frame_id : frame_id_;
  odom.child_frame_id = "base_link";
  odom.pose.pose = pose->pose;
  odom.twist.twist = twist->twist;
  odom_pub_.publish(odom);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "fusion_odom");
  ros::NodeHandle nh("~");
  FusionOdom node;
  node.init(nh);
  ros::spin();
  return 0;
}
