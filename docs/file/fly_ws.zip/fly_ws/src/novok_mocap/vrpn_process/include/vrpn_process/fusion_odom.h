#ifndef VRPN_PROCESS_FUSION_ODOM_H
#define VRPN_PROCESS_FUSION_ODOM_H

#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/TwistStamped.h>

#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

#include <string>

class FusionOdom
{
public:
  FusionOdom() = default;
  ~FusionOdom();
  void init(ros::NodeHandle &nh);

private:
  using SyncPolicy =
      message_filters::sync_policies::ApproximateTime<geometry_msgs::PoseStamped,
                                                      geometry_msgs::TwistStamped>;

  std::string pose_topic_{"/vrpn_client_node/MVD/pose"};
  std::string twist_topic_{"/vrpn_client_node/MVD/twist"};
  std::string odom_topic_{"/MVD/odom"};
  std::string frame_id_{"world"};

  ros::Publisher odom_pub_;
  message_filters::Subscriber<geometry_msgs::PoseStamped> *pose_sub_{nullptr};
  message_filters::Subscriber<geometry_msgs::TwistStamped> *twist_sub_{nullptr};
  message_filters::Synchronizer<SyncPolicy> *sync_{nullptr};

  void callback(const geometry_msgs::PoseStampedConstPtr &pose,
                const geometry_msgs::TwistStampedConstPtr &twist);
};

#endif
