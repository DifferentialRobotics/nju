#!/bin/bash

source ../realsense_ros/devel/setup.bash
roslaunch realsense2_camera rs_vins_d430.launch & sleep 3;

source ../vins_fusion_gpu/devel/setup.bash
rosrun vins vins_node ../vins_fusion_gpu/src/config/realsense_d430/realsense_stereo_imu_config.yaml
wait;