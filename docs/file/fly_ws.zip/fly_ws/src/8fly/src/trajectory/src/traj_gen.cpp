/*
 * @Brief:
 * @Author: Xinwei Chen
 * @Date: 2024-07-07 17:34:16
 * @Last Modified by: Xinwei Chen
 * @Last Modified time: 2024-07-08 15:49:31
 */

#include <ros/ros.h>

#include <tf/tf.h>
#include <std_msgs/Bool.h>
#include <geometry_msgs/PoseStamped.h>

#include <minco/traj_gen.hpp>
#include <trajectory/common.h>
#include <trajectory/visual.h>
#include <trajectory/trajectory.h>

#include <Eigen/Eigen>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "pubtraj");

    ros::NodeHandle nh, pnh("~");
    ros::AsyncSpinner spinner(1);

    // publush the trajectory
    ros::Publisher traj_pub = nh.advertise<quadrotor_msgs::PolynomialTrajectory>("trajectory", 1);
    ros::Publisher cmd_vis_pub = nh.advertise<visualization_msgs::Marker>("cmd_visual", 1);
    minco_utils::MincoTrajParams poly_config_data = std::move(minco_utils::MincoTrajParams::getMincoTrajParams(pnh));
    ROS_WARN("[traj_gen] shape=%d (0=eight,1=circle,2=star,3=s,4=rings), rings=%zu, gateApproachDist=%.3f",
             poly_config_data.shape, poly_config_data.rings.size(), poly_config_data.gateApproachDist);

    trajectory::visual::TrajectoryVisualizer traj_visualizer("trajectory_vis", nh);

    auto START_TIME = ros::Time::now();

    Eigen::Vector3d odom_pos = Eigen::Vector3d::Zero();
    Eigen::Vector3d odom_vel = Eigen::Vector3d::Zero();
    double yaw = 0.0;
    bool odom_received = false;
    ros::Subscriber odom_sub = nh.subscribe<nav_msgs::Odometry>(
        "odom", 1,
        [&odom_pos, &odom_vel, &yaw, &odom_received](const nav_msgs::Odometry::ConstPtr &msg_ptr)
        {
            odom_pos << msg_ptr->pose.pose.position.x, msg_ptr->pose.pose.position.y, msg_ptr->pose.pose.position.z;
            odom_vel << msg_ptr->twist.twist.linear.x, msg_ptr->twist.twist.linear.y, msg_ptr->twist.twist.linear.z;
            Eigen::Quaterniond q(msg_ptr->pose.pose.orientation.w,
                                 msg_ptr->pose.pose.orientation.x,
                                 msg_ptr->pose.pose.orientation.y,
                                 msg_ptr->pose.pose.orientation.z);
            double siny_cosp = 2 * (q.w() * q.z() + q.x() * q.y());
            double cosy_cosp = 1 - 2 * (q.y() * q.y() + q.z() * q.z());
            yaw = atan2(siny_cosp, cosy_cosp);
            if (!odom_received) {
                ROS_WARN("Receive the odom message!");
                odom_received = true;
            }
        });

    // subscribe to the run trigger
    geometry_msgs::PoseStamped RUN_TRIGGER_MSG;
    minco_utils::Trajectory FOLLOW_TRAJ_MINCO;
    const std::string RUN_TRIGGER_TOPIC = "move_base_simple/goal";
    ros::Subscriber run_trigger_sub = nh.subscribe<geometry_msgs::PoseStamped>(
        RUN_TRIGGER_TOPIC, 1,
        [&traj_pub, &poly_config_data, &traj_visualizer, &START_TIME, &RUN_TRIGGER_MSG, &odom_pos, &odom_vel, &yaw, &odom_received, &FOLLOW_TRAJ_MINCO](const geometry_msgs::PoseStamped::ConstPtr &msg_ptr)
        {   
            if (!odom_received) {
                ROS_WARN("No odom message received!");
                return;
            } else if (odom_vel.norm() > 0.3) {
                ROS_WARN("The quadrotor is moving!");
                return;
            }
            ROS_WARN("Receive a new trigger, publishing the trajectory!");
            poly_config_data.init_pos = odom_pos;
            poly_config_data.yaw = yaw;
            if (poly_config_data.shape == minco_utils::RINGS)
            {
                ROS_WARN("[traj_gen] RINGS trigger from hover (%.3f, %.3f, %.3f), yaw=%.3f, %zu gates",
                         odom_pos.x(), odom_pos.y(), odom_pos.z(), yaw, poly_config_data.rings.size());
                for (size_t i = 0; i < poly_config_data.rings.size(); ++i)
                {
                    const auto &g = poly_config_data.rings[i];
                    ROS_WARN("[traj_gen]   gate[%zu] c=(%.3f,%.3f,%.3f) n=(%.3f,%.3f,%.3f)",
                             i, g.center.x(), g.center.y(), g.center.z(),
                             g.normal.x(), g.normal.y(), g.normal.z());
                }
            }
            FOLLOW_TRAJ_MINCO = trajectory::generateMincoOriTrajectory(poly_config_data);
            quadrotor_msgs::PolynomialTrajectory FOLLOW_TRAJ_POLY = trajectory::generatePolyTrajectory(FOLLOW_TRAJ_MINCO);
            FOLLOW_TRAJ_POLY.start_yaw = yaw;
            FOLLOW_TRAJ_POLY.final_yaw = yaw;
            trajectory::common::Trajectory FOLLOW_TRAJ_CUSTOM = trajectory::generateCustomTrajectory(poly_config_data.dt, FOLLOW_TRAJ_MINCO);
            ROS_WARN("[traj_gen] published traj: segments=%d, vis_points=%zu, duration≈%.2fs",
                     FOLLOW_TRAJ_POLY.num_segment, FOLLOW_TRAJ_CUSTOM.points.size(),
                     FOLLOW_TRAJ_MINCO.getTotalDuration());
            traj_pub.publish(FOLLOW_TRAJ_POLY);
            traj_visualizer.setTrajectory(FOLLOW_TRAJ_CUSTOM);
            traj_visualizer.publishTrajectory();
            START_TIME = ros::Time::now();
            RUN_TRIGGER_MSG = *msg_ptr;
        });

    visualization_msgs::Marker cmd_vis_marker;

    spinner.start();
    ros::Rate rate(100);

    while (ros::ok())
    {
        if (RUN_TRIGGER_MSG.header.stamp.toSec() == 0.0)
        {
            START_TIME = ros::Time::now();
            continue;
        }

        auto current_time = (ros::Time::now() - START_TIME).toSec();
        auto cur_traj_point = trajectory::getCurTimeTrajectoryPoint(FOLLOW_TRAJ_MINCO, current_time);
        Eigen::Vector3d euler = cur_traj_point.orientation.toRotationMatrix().eulerAngles(2, 1, 0);
        double yaw = euler[0];
        if (cur_traj_point.velocity.norm() > 1.0)
            cmd_vis_marker = trajectory::visual::genVisualMarker(cur_traj_point.position,
                                                                     cur_traj_point.position + cur_traj_point.velocity.normalized().norm() * Eigen::Vector3d(cos(yaw), sin(yaw), 0.0),
                                                                     trajectory::visual::VISUAL_COLOR::RED,
                                                                     0);
        else
            cmd_vis_marker = trajectory::visual::genVisualMarker(cur_traj_point.position,
                                                                     cur_traj_point.position + cur_traj_point.velocity.norm() * Eigen::Vector3d(cos(yaw), sin(yaw), 0.0),
                                                                     trajectory::visual::VISUAL_COLOR::RED,
                                                                     0);

        cmd_vis_pub.publish(cmd_vis_marker);

        ros::spinOnce();
    }
    spinner.stop();
    return 0;
}