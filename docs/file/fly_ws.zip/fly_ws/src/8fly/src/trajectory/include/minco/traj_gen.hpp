/*
 * @Author: Xinwei Chen
 * @Date: 2024-02-19 14:24:22
 * @Last Modified by: Xinwei Chen
 * @Last Modified time: 2024-02-19 14:24:25
 */

#ifndef TRAJ_GEN_H
#define TRAJ_GEN_H

#include <minco/traj_opt.h>
#include <minco/minco.hpp>

#include <ros/ros.h>
#include <xmlrpcpp/XmlRpcValue.h>

#include <vector>

namespace minco_utils
{

    enum TrajShape
    {
        EIGHT = 0,
        CIRCLE,
        STAR,
        SCURVE,
        RINGS
    };

    enum TrajType
    {
        CONTINUOUS = 0,
        DISCONTINUOUS
    };

    struct RingGate
    {
        Eigen::Vector3d center = Eigen::Vector3d::Zero();
        Eigen::Vector3d normal = Eigen::Vector3d::UnitX();
    };

    struct MincoTrajParams
    {
        int K = 32;
        int shape = 0;
        double dt = 0.05;
        double rhoT = 1000;
        double rhoV = 20000;
        double rhoA = 20000;
        double maxVel = 1.0;
        double maxAcc = 1.0;
        double eightWidth = 3.0;
        double eightLength = 6.0;
        double circleRadius = 3.0;
        double starRadius = 3.0;
        double sWidth = 3.0;
        double sLength = 14.0;
        double startX = 0.0;
        double startY = 0.0;
        double endX = 0.0;
        double endY = 0.0;
        double height = 0.0;
        bool pauseDebug = false;
        Eigen::Vector3d init_pos = Eigen::Vector3d::Zero();
        double yaw = 0.0;

        double gateApproachDist = 0.5;
        bool ringsReturnHome = false;
        std::vector<RingGate> rings;

        static bool loadRings(const ros::NodeHandle &pnh, std::vector<RingGate> &rings_out)
        {
            XmlRpc::XmlRpcValue rings_param;
            if (!pnh.getParam("rings", rings_param))
            {
                ROS_WARN("[MincoTrajParams] shape=RINGS but param 'rings' is missing");
                return false;
            }
            if (rings_param.getType() != XmlRpc::XmlRpcValue::TypeArray || rings_param.size() < 1)
            {
                ROS_WARN("[MincoTrajParams] 'rings' must be a non-empty array");
                return false;
            }

            rings_out.clear();
            rings_out.reserve(rings_param.size());
            for (int i = 0; i < rings_param.size(); ++i)
            {
                if (rings_param[i].getType() != XmlRpc::XmlRpcValue::TypeStruct)
                {
                    ROS_WARN("[MincoTrajParams] rings[%d] must be a struct", i);
                    return false;
                }
                auto &entry = rings_param[i];
                if (!entry.hasMember("x") || !entry.hasMember("y") || !entry.hasMember("z") ||
                    !entry.hasMember("nx") || !entry.hasMember("ny") || !entry.hasMember("nz"))
                {
                    ROS_WARN("[MincoTrajParams] rings[%d] needs x,y,z,nx,ny,nz", i);
                    return false;
                }

                auto asDouble = [](XmlRpc::XmlRpcValue &v) -> double {
                    if (v.getType() == XmlRpc::XmlRpcValue::TypeInt)
                        return static_cast<int>(v);
                    return static_cast<double>(v);
                };

                RingGate gate;
                gate.center = Eigen::Vector3d(asDouble(entry["x"]),
                                              asDouble(entry["y"]),
                                              asDouble(entry["z"]));
                gate.normal = Eigen::Vector3d(asDouble(entry["nx"]),
                                              asDouble(entry["ny"]),
                                              asDouble(entry["nz"]));
                const double nrm = gate.normal.norm();
                if (nrm < 1e-6)
                {
                    ROS_WARN("[MincoTrajParams] rings[%d] normal is near zero", i);
                    return false;
                }
                gate.normal /= nrm;
                rings_out.push_back(gate);
            }
            return true;
        }

        static MincoTrajParams getMincoTrajParams(const ros::NodeHandle &pnh)
        {
            MincoTrajParams params;
            bool is_param_ok = true;

            is_param_ok &= pnh.getParam("K", params.K);
            is_param_ok &= pnh.getParam("shape", params.shape);
            is_param_ok &= pnh.getParam("dt", params.dt);
            is_param_ok &= pnh.getParam("rhoT", params.rhoT);
            is_param_ok &= pnh.getParam("rhoV", params.rhoV);
            is_param_ok &= pnh.getParam("rhoA", params.rhoA);
            is_param_ok &= pnh.getParam("maxVel", params.maxVel);
            is_param_ok &= pnh.getParam("maxAcc", params.maxAcc);
            is_param_ok &= pnh.getParam("eightWidth", params.eightWidth);
            is_param_ok &= pnh.getParam("eightLength", params.eightLength);
            is_param_ok &= pnh.getParam("circleRadius", params.circleRadius);
            is_param_ok &= pnh.getParam("starRadius", params.starRadius);
            is_param_ok &= pnh.getParam("sWidth", params.sWidth);
            is_param_ok &= pnh.getParam("sLength", params.sLength);
            is_param_ok &= pnh.getParam("startX", params.startX);
            is_param_ok &= pnh.getParam("startY", params.startY);
            is_param_ok &= pnh.getParam("endX", params.endX);
            is_param_ok &= pnh.getParam("endY", params.endY);
            is_param_ok &= pnh.getParam("height", params.height);
            is_param_ok &= pnh.getParam("pauseDebug", params.pauseDebug);

            if (params.shape == RINGS)
            {
                pnh.param("gateApproachDist", params.gateApproachDist, 0.5);
                pnh.param("ringsReturnHome", params.ringsReturnHome, false);
                is_param_ok &= loadRings(pnh, params.rings);
                is_param_ok &= (params.gateApproachDist > 0.0);
            }

            const bool common_ok =
                is_param_ok && params.K > 0 && params.shape >= 0 && params.shape <= RINGS &&
                params.dt > 0 && params.rhoT > 0 && params.rhoV > 0 && params.rhoA > 0 &&
                params.maxVel > 0 && params.maxAcc > 0;

            bool shape_ok = true;
            if (params.shape != RINGS)
            {
                shape_ok = params.eightWidth > 0 && params.eightLength > 0 &&
                           params.circleRadius > 0 && params.starRadius > 0 &&
                           params.sWidth > 0 && params.sLength > 0;
            }
            else
            {
                shape_ok = !params.rings.empty();
            }

            if (!common_ok || !shape_ok)
            {
                ROS_WARN("[MincoTrajParams::getMincoTrajParams] parameter error");
                exit(1);
            }

            return params;
        }
    };

    class TrajGenerator
    {
    public:
        // constructor
        TrajGenerator() = delete;
        TrajGenerator(const MincoTrajParams &data);
        TrajGenerator(const TrajGenerator &rhs) = delete;
        TrajGenerator &operator=(const TrajGenerator &rhs) = delete;
        TrajGenerator(TrajGenerator &&rhs) = delete;
        TrajGenerator &operator=(TrajGenerator &&rhs) = delete;
        virtual ~TrajGenerator() {}

        // getters
        Trajectory get_minco_traj() const { return minco_traj_; }

    private:
        MincoTrajParams data_;
        Trajectory minco_traj_;

        void generate_traj();

        static void allocateSegmentTimes(const Eigen::Vector3d &init_pos,
                                         const Eigen::Vector3d &final_pos,
                                         const std::vector<Eigen::Vector3d> &Q,
                                         int N,
                                         double max_vel,
                                         std::vector<double> &T)
        {
            T.clear();
            T.reserve(N);
            for (int i = 0; i < N; i++)
            {
                double dis;
                if (i == 0)
                    dis = (init_pos - Q[i]).norm();
                else if (i == N - 1)
                    dis = (final_pos - Q[i - 1]).norm();
                else
                    dis = (Q[i] - Q[i - 1]).norm();
                T.push_back(std::max(dis / max_vel, 1e-3));
            }
        }

    }; // class TrajGenerator

    void TrajGenerator::generate_traj()
    {
        // Define trajectory state
        Eigen::MatrixXd initState = Eigen::MatrixXd::Zero(3, 3);
        Eigen::MatrixXd finalState = Eigen::MatrixXd::Zero(3, 3);
        Eigen::Vector3d initStateV = Eigen::Vector3d::Zero();
        Eigen::Vector3d finalStateV = Eigen::Vector3d::Zero();
        initState(0, 0) = initStateV(0) = data_.init_pos(0);
        initState(1, 0) = initStateV(1) = data_.init_pos(1);
        initState(2, 0) = initStateV(2) = data_.init_pos(2);
        finalState(0, 0) = finalStateV(0) = data_.init_pos(0);
        finalState(1, 0) = finalStateV(1) = data_.init_pos(1);
        finalState(2, 0) = finalStateV(2) = data_.init_pos(2);

        std::vector<Eigen::Vector3d> Q;
        std::vector<double> T;
        int N = 0;

        int trajType = CONTINUOUS;

        if (data_.shape == EIGHT) // Eight
        {
            double eightWidth = data_.eightWidth;
            double eightLength = data_.eightLength;
            double offsetX = initState(0, 0);
            double offsetY = initState(1, 0);

            Eigen::VectorXd PosX(7), PosY(7);
            PosX << eightLength / 4, eightLength / 2, eightLength / 4, 0.0, -eightLength / 4, -eightLength / 2, -eightLength / 4;
            PosY << -eightWidth / 2, 0.0, eightWidth / 2, 0.0, -eightWidth / 2, 0.0, eightWidth / 2;

            N = PosX.size() + 1;
            Eigen::Quaterniond q(cos(data_.yaw / 2), 0, 0, sin(data_.yaw / 2));
            std::cout << "yaw = " << data_.yaw << std::endl;
            for (int i = 0; i < N - 1; i++)
            {
                Eigen::Vector3d wp(PosX(i),
                                   PosY(i),
                                   initState(2, 0));
                wp = q * wp;
                wp.x() += offsetX;
                wp.y() += offsetY;
                Q.push_back(wp);
            }

            allocateSegmentTimes(initStateV, finalStateV, Q, N, data_.maxVel, T);
            trajType = CONTINUOUS;
        }
        else if (data_.shape == CIRCLE) // Circle
        {
            double R = data_.circleRadius;
            double offsetX = initState(0, 0) - R;
            double offsetY = initState(1, 0);

            N = 100;
            for (int i = 1; i < N; i++)
            {
                Eigen::Vector3d wp(R * cos(i * 2 * M_PI / N) + offsetX,
                                   -R * sin(i * 2 * M_PI / N) + offsetY,
                                   initState(2, 0));
                Q.push_back(wp);
            }

            allocateSegmentTimes(initStateV, finalStateV, Q, N, data_.maxVel, T);
            trajType = CONTINUOUS;
        }
        else if (data_.shape == STAR)
        {
            double R = data_.starRadius;
            double r = R * 0.65;
            double offsetX = initState(0, 0) - R;
            double offsetY = initState(1, 0);

            Eigen::VectorXd PosX(9), PosY(9);
            PosX << r * sin(54 * M_PI / 180), R * sin(18 * M_PI / 180), -r * sin(18 * M_PI / 180), -R * sin(54 * M_PI / 180), -r, -R * sin(54 * M_PI / 180), -r * sin(18 * M_PI / 180), R * sin(18 * M_PI / 180), r * sin(54 * M_PI / 180);
            PosY << -r * cos(54 * M_PI / 180), -R * cos(18 * M_PI / 180), -r * cos(18 * M_PI / 180), -R * cos(54 * M_PI / 180), 0, R * cos(54 * M_PI / 180), r * cos(18 * M_PI / 180), R * cos(18 * M_PI / 180), r * cos(54 * M_PI / 180);

            N = PosX.size() + 1;
            for (int i = 0; i < N - 1; i++)
            {
                Eigen::Vector3d wp(PosX(i) + offsetX,
                                   PosY(i) + offsetY,
                                   initState(2, 0));
                Q.push_back(wp);
            }

            allocateSegmentTimes(initStateV, finalStateV, Q, N, data_.maxVel, T);
            trajType = CONTINUOUS;
        }
        else if (data_.shape == SCURVE) // S-Curve
        {
            finalState(0, 0) += data_.sLength;
            finalStateV(0) += data_.sLength;
            finalState(1, 0) -= data_.sWidth;
            finalStateV(1) -= data_.sWidth;

            double sWidth = data_.sWidth;
            double sLength = data_.sLength;
            double sPerLength = sLength / 7;
            double offsetX = initState(0, 0);
            double offsetY = initState(1, 0);

            finalState(0, 0) = sLength + offsetX;
            finalState(1, 0) = -sWidth + offsetY;
            finalStateV = finalState.col(0);

            Eigen::VectorXd PosX(6), PosY(6);
            PosX << sPerLength, 2 * sPerLength, 3 * sPerLength, 4 * sPerLength, 5 * sPerLength, 6 * sPerLength;
            PosY << -sWidth, -sWidth / 2, 0.0, -sWidth, -sWidth / 2, 0.0;

            N = PosX.size() + 1;
            for (int i = 0; i < N - 1; i++)
            {
                Eigen::Vector3d wp(PosX(i) + offsetX,
                                   PosY(i) + offsetY,
                                   initState(2, 0));
                Q.push_back(wp);
            }

            allocateSegmentTimes(initStateV, finalStateV, Q, N, data_.maxVel, T);
            trajType = DISCONTINUOUS;
        }
        else if (data_.shape == RINGS)
        {
            // One waypoint per ring: the gate center only (no approach/exit).
            std::vector<Eigen::Vector3d> wps;
            wps.reserve(data_.rings.size());

            ROS_WARN("[TrajGenerator] RINGS: %zu gates (center-only), return_home=%d",
                     data_.rings.size(), static_cast<int>(data_.ringsReturnHome));

            for (size_t i = 0; i < data_.rings.size(); ++i)
            {
                const auto &gate = data_.rings[i];
                wps.push_back(gate.center);
                ROS_WARN("[TrajGenerator] ring[%zu] c=(%.3f,%.3f,%.3f)",
                         i, gate.center.x(), gate.center.y(), gate.center.z());
            }

            if (data_.ringsReturnHome)
            {
                // Out-and-back along centers: c1..cn then cn-1..c1, finally hover.
                // e.g. 4 rings → Q = [c1,c2,c3,c4,c3,c2,c1], final = init_pos
                Q = wps;
                if (wps.size() >= 2)
                {
                    for (int i = static_cast<int>(wps.size()) - 2; i >= 0; --i)
                        Q.push_back(wps[static_cast<size_t>(i)]);
                }
                finalState.col(0) = data_.init_pos;
                finalStateV = data_.init_pos;
            }
            else
            {
                finalState.col(0) = wps.back();
                finalStateV = wps.back();
                Q.assign(wps.begin(), wps.end() - 1);
            }

            N = static_cast<int>(Q.size()) + 1;
            allocateSegmentTimes(initStateV, finalStateV, Q, N, data_.maxVel, T);
            trajType = DISCONTINUOUS;

            ROS_WARN("[TrajGenerator] RINGS waypoints: |Q|=%zu, N=%d, final=(%.3f,%.3f,%.3f)",
                     Q.size(), N, finalStateV.x(), finalStateV.y(), finalStateV.z());
        }
        else
        {
            ROS_WARN("Don't exist this trajectory type!!!");
        }

        // Set trajectory
        TrajOpt::Ptr minco_traj_optimizer;

        minco_traj_optimizer.reset(new TrajOpt);
        int ret_value;
        bool ret_opt;

        Eigen::VectorXd minco_param(5);
        minco_param << data_.maxVel, data_.maxAcc, data_.rhoT, data_.rhoV, data_.rhoA;
        minco_traj_optimizer->setParam(data_.K, data_.pauseDebug, minco_param);

        ret_opt = minco_traj_optimizer->generate_traj(initState, finalState, Q, T, N, minco_traj_, false, ret_value);
        if (!ret_opt)
        {
            ROS_ERROR("[TrajGenerator] MINCO optimize failed, ret=%d", ret_value);
        }
        minco_traj_.setTrajType(trajType);
    }

    TrajGenerator::TrajGenerator(const MincoTrajParams &data) : data_(data)
    {
        generate_traj();
    }

} // namespace minco_utils

#endif // TRAJ_GEN_H
