#!/bin/bash
source ./px4_ctrl/devel/setup.bash

rostopic pub -1 /px4ctrl/takeoff_land quadrotor_msgs/TakeoffLand "takeoff_land_cmd: 2"
