#include <algorithm>
#include <string>

#include <gazebo_msgs/ModelStates.h>
#include <nav_msgs/Odometry.h>
#include <ros/ros.h>

namespace {

nav_msgs::Odometry genOdomFromGZ(const gazebo_msgs::ModelStates &gz_msg,
                                 const std::string &model_name,
                                 bool *found) {
  nav_msgs::Odometry odom;
  odom.header.stamp = ros::Time::now();

  const auto it =
      std::find(gz_msg.name.begin(), gz_msg.name.end(), model_name);
  if (it == gz_msg.name.end()) {
    *found = false;
    return odom;
  }

  const auto index = static_cast<size_t>(
      std::distance(gz_msg.name.begin(), it));
  odom.pose.pose = gz_msg.pose[index];
  // Gazebo ModelStates twist is expressed in the WORLD frame.
  odom.twist.twist = gz_msg.twist[index];
  *found = true;
  return odom;
}

}  // namespace

int main(int argc, char **argv) {
  ros::init(argc, argv, "gazebo_odom_node");
  ros::NodeHandle nh;
  ros::NodeHandle pnh("~");

  std::string model_name;
  std::string gazebo_topic;
  std::string odom_topic;
  std::string frame_id;
  std::string child_frame_id;
  double publish_rate = 200.0;

  pnh.param<std::string>("model_name", model_name, "iris");
  pnh.param<std::string>("gazebo_topic", gazebo_topic, "/gazebo/model_states");
  pnh.param<std::string>("odom_topic", odom_topic, "/drone0/odom");
  pnh.param<std::string>("frame_id", frame_id, "world");
  pnh.param<std::string>("child_frame_id", child_frame_id, "base_link");
  pnh.param("publish_rate", publish_rate, 200.0);

  ros::Publisher odom_pub =
      nh.advertise<nav_msgs::Odometry>(odom_topic, 10);

  nav_msgs::Odometry latest_odom;
  bool has_odom = false;
  bool warned_missing = false;

  ros::Subscriber gz_sub = nh.subscribe<gazebo_msgs::ModelStates>(
      gazebo_topic, 1,
      [&](const gazebo_msgs::ModelStates::ConstPtr &msg) {
        bool found = false;
        nav_msgs::Odometry odom = genOdomFromGZ(*msg, model_name, &found);
        if (!found) {
          if (!warned_missing) {
            ROS_WARN_THROTTLE(
                2.0,
                "[gazebo_odom] model '%s' not found on %s; waiting...",
                model_name.c_str(), gazebo_topic.c_str());
            warned_missing = true;
          }
          return;
        }
        warned_missing = false;
        odom.header.frame_id = frame_id;
        odom.child_frame_id = child_frame_id;
        latest_odom = odom;
        has_odom = true;
      });

  ROS_INFO(
      "[gazebo_odom] model=%s  gazebo=%s  odom=%s  rate=%.1f Hz",
      model_name.c_str(), gazebo_topic.c_str(), odom_topic.c_str(),
      publish_rate);

  ros::Rate rate(publish_rate);
  while (ros::ok()) {
    ros::spinOnce();
    if (has_odom) {
      latest_odom.header.stamp = ros::Time::now();
      odom_pub.publish(latest_odom);
    }
    rate.sleep();
  }
  return 0;
}
