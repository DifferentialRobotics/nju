#!/bin/bash
sudo chmod 777 /dev/tty* & sleep 5;
roslaunch mavros px4.launch & sleep 6;
rosrun mavros mavcmd long 511 105 5000 0 0 0 0 0 & sleep 1;
rosrun mavros mavcmd long 511 31 5000 0 0 0 0 0 & sleep 1;
source devel/setup.bash;
roslaunch vrpn_client_ros sample.launch & sleep 5;
roslaunch vrpn_process fusion_odom.launch & sleep 3;
# roslaunch ekf nokov.launch & sleep 3;
wait;