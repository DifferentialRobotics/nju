#!/bin/bash
source ./px4_ctrl/devel/setup.bash

roslaunch px4ctrl run_ctrl.launch & sleep 1;
roslaunch trajectory fly_test.launch & sleep 1;

wait;
