#!/bin/bash
sudo chmod 777 /dev/ttyTHS0

roslaunch mavros px4.launch & sleep 3;
# roslaunch mavros px4.launch gcs_url:="udp://@192.168.5.122" & sleep 4;
rosrun mavros mavcmd long 511 31 5000 0 0 0 0 0 & sleep 1;
rosrun mavros mavcmd long 511 83 5000 0 0 0 0 0 & sleep 1;
rosrun mavros mavcmd long 511 105 5000 0 0 0 0 0 & sleep 1;

wait;
