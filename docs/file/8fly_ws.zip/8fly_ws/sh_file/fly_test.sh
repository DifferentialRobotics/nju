#!/bin/bash
# Start px4ctrl + fly_test trajectory.
#
# Usage: ./fly_test.sh [gt|vio|lio]   (default: gt for Gazebo SITL)
#
# SITL prerequisites (other terminals):
#   1) roslaunch px4 mavros_posix_sitl.launch   # already has mavros
#   2) ./sh_file/mavros_rate.sh                # raise IMU rate
#   3) ./sh_file/run_groundtruth.sh            # /drone0/odom
# Then takeoff: ./sh_file/takeoff.sh
# Then trigger traj: ./sh_file/pub_trigger.sh
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${WS_DIR}/devel/setup.bash"

CTRL_MODE="${1:-gt}"
if [[ "${CTRL_MODE}" == "gt" ]]; then
  CTRL_LAUNCH="run_ctrl_gt.launch"
  EXPECT_ODOM="/drone0/odom"
else
  CTRL_LAUNCH="run_ctrl_${CTRL_MODE}.launch"
  if [[ "${CTRL_MODE}" == "vio" ]]; then
    EXPECT_ODOM="/vins/imu_propagate"
  else
    EXPECT_ODOM="/ekf/ekf_odom"
  fi
fi

echo "[fly_test] launching px4ctrl with ${CTRL_LAUNCH}"
echo "[fly_test] px4ctrl expects odom on: ${EXPECT_ODOM}"

roslaunch px4ctrl "${CTRL_LAUNCH}" & sleep 2
roslaunch trajectory fly_test.launch & sleep 1

echo "[fly_test] verify:"
echo "  rosnode list | grep px4ctrl"
echo "  rostopic info ${EXPECT_ODOM}   # subscribers should include /px4ctrl"
echo "  rostopic hz /mavros/imu/data   # should be ~200Hz after mavros_rate.sh"

wait