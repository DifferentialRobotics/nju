#!/bin/bash
# Publish Gazebo model ground-truth as /drone0/odom (nav_msgs/Odometry).
#
# Usage:
#   ./run_groundtruth.sh [model_name] [odom_topic]
# Defaults: iris , /drone0/odom
#
# Prerequisite: Gazebo / PX4 SITL already running and publishing
#   /gazebo/model_states
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WS_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${WS_DIR}/devel/setup.bash"

MODEL_NAME="${1:-iris}"
ODOM_TOPIC="${2:-/drone0/odom}"

roslaunch groundtruth groundtruth.launch \
  model_name:="${MODEL_NAME}" \
  odom_topic:="${ODOM_TOPIC}"
