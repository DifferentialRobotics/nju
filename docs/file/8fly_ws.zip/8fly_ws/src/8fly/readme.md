change config in trajectory/parameters/traj.yaml
run traj test with:
roslaunch trajectory fly_test.launch