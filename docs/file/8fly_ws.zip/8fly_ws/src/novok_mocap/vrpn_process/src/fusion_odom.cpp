#include <fusion_odom.h>

using namespace std;

fusionOdom::~fusionOdom()
{
    delete sync_;
    delete rawPoseSub;
    delete rawLinearSub;
}


void fusionOdom::init(ros::NodeHandle &nh)
{
    // Initialized parameter

    // Publisher and subscriber
    fusionOdomPub = nh.advertise<nav_msgs::Odometry>(fusionOdomTopic, 10);

    rawPoseSub = new message_filters::Subscriber<nav_msgs::Odometry>(nh, rawPoseTopic, 10);
    rawLinearSub = new message_filters::Subscriber<geometry_msgs::TwistStamped>(nh, rawLinearTopic, 10);

    sync_ = new message_filters::Synchronizer<GpsSyncPolicy>(GpsSyncPolicy(10), *rawPoseSub, *rawLinearSub);
    sync_-> registerCallback(boost::bind(&fusionOdom::fusionHandler, this, _1, _2));

}

void fusionOdom::fusionHandler(const nav_msgs::Odometry::ConstPtr& poseIn, const geometry_msgs::TwistStamped::ConstPtr& linearIn)
{
    nav_msgs::Odometry fusionOdom;
    fusionOdom.header.frame_id = "world";
    fusionOdom.header.stamp = poseIn->header.stamp;

    fusionOdom.pose.pose = poseIn->pose.pose;
    fusionOdom.twist.twist.linear = linearIn->twist.linear;

    fusionOdomPub.publish(fusionOdom);
}

int main(int argc, char *argv[])
{
    ros::init(argc, argv, "fusion_odom");
    ros::NodeHandle nh("~");

    fusionOdom fusion_odom;
    fusion_odom.init(nh);

    ros::AsyncSpinner spinner(2);

    spinner.start();

    ros::waitForShutdown();

    return 0;
}