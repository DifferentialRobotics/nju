#ifndef _FUSION_ODOM_H
#define _FUSION_ODOM_H

#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <geometry_msgs/TwistStamped.h>

#include <fstream>
#include <boost/thread/thread.hpp>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>

#include <Eigen/Eigen>
#include <Eigen/Dense>

using namespace std;

class fusionOdom
{
private:
	/*---------- Parameters ----------*/

    string rawPoseTopic = "/vrpn_client_node/cxw_fpv/pose";
    string rawLinearTopic = "/vrpn_client_node/cxw_fpv/twist";
    string fusionOdomTopic = "/vrpn_client_node/cxw_fpv/odom";


	/*---------- Function ----------*/
	/* Publisher */
	ros::Publisher fusionOdomPub;

	/* Subscriber */
    typedef message_filters::sync_policies::ApproximateTime<nav_msgs::Odometry, geometry_msgs::TwistStamped> GpsSyncPolicy;
    message_filters::Synchronizer<GpsSyncPolicy>* sync_;
    message_filters::Subscriber<nav_msgs::Odometry>* rawPoseSub;
    message_filters::Subscriber<geometry_msgs::TwistStamped>* rawLinearSub;

	/* Server */

	/* Timer */

	/* ROS function */
    void fusionHandler(const nav_msgs::Odometry::ConstPtr& poseIn, const geometry_msgs::TwistStamped::ConstPtr& linearIn);

	/* Other function */

	/* Debug function */

public:
	fusionOdom(){};
	~fusionOdom();

	void init(ros::NodeHandle &nh);
};

#endif